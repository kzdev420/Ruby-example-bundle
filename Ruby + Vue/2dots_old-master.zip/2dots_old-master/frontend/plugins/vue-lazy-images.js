import Vue from "vue"
import VueLazyImage from "vue-lazy-images";
Vue.use(VueLazyImage)