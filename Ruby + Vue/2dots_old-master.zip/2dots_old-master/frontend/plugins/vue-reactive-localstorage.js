import Vue from 'vue'
import ReactiveStorage from "vue-reactive-localstorage";

Vue.use(ReactiveStorage, {
  token: '',
});

