import Vue from 'vue'

import Lingallery from 'lingallery';
Vue.component('lingallery', Lingallery);
