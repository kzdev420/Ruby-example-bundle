export const state = () => ({
    contactAgent:{
        name:'',
        message:'',
        email:''
    }
})
