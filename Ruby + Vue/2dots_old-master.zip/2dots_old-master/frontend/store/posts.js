export const state = () => ({
  posts: [{
      image: 'https://i1.wp.com/graphics-for-less.com/wp-content/uploads/edd/2015/11/woman-avatar-4.png?zoom=2.625&fit=975%2C600',
      title: 'Parturient Euismod Consectetur Risus',
      replies: '40',
      shortcontent: '',
      purpose: '',
      datePosted: '',
      postedBy: ''
    },
    {
      image: 'https://images.vexels.com/media/users/3/145922/preview2/eb6591b54b2b6462b4c22ec1fc4c36ea-female-avatar-maker.jpg',
      title: 'Parturient Euismod Consectetur Risus',
      replies: '40',
      shortcontent: '',
      purpose: '',
      datePosted: '',
      postedBy: ''
    },
    {
      image: 'https://cdn.pixabay.com/photo/2016/08/20/05/36/avatar-1606914_960_720.png',
      title: 'Parturient Euismod Consectetur Risus',
      replies: '40',
      shortcontent: '',
      purpose: '',
      datePosted: '',
      postedBy: ''
    },
    {
      image: 'https://cdn.pixabay.com/photo/2013/07/13/10/07/man-156584__340.png',
      title: 'Parturient Euismod Consectetur Risus',
      replies: '40',
      shortcontent: '',
      purpose: '',
      datePosted: '',
      postedBy: ''
    },
    {
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkvjPx1xjcTZsr507_cODyF1zTvmFs-1WFj9XT05DzlaIbUKUu',
      title: 'Parturient Euismod Consectetur Risus',
      replies: '40',
      shortcontent: '',
      purpose: '',
      datePosted: '',
      postedBy: ''
    }
  ],
  replies: [{
    image: 'https://www.iti.org.uk/images/article-images/Profile-Interview-Photo---Fiona-Gray.jpg',
    content: " Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus ",
    datePosted: '',
    postedBy: ''
  },
  {
    image: 'http://dqg.org/multimedia/Testimonial/testIMG1528182709.jpg',
    content: " Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus ",
    datePosted: '',
    postedBy: ''
  },
  {
    image: 'https://i.dailymail.co.uk/i/pix/2017/04/20/13/3F6B966D00000578-4428630-image-m-80_1492690622006.jpg',
    content: " Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus ",
    datePosted: '',
    postedBy: ''
  },
  {
    image: 'https://img.kpopmap.com/2018/10/Bang-Jaemin-profile-cover-bnt.jpg',
    content: " Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus ",
    datePosted: '',
    postedBy: ''
  },
  {
    image: 'http://drforum.gemini.edu/wp-content/uploads/2019/02/to03on_avatar_1550127934.jpg',
    content: " Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus ",
    datePosted: '',
    postedBy: ''
  }

]

})
