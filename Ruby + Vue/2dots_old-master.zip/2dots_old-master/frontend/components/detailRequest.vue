<template>
  <div>
    <div class="tds-detail-grid">
      <div class="grid-one-column">
        <div class="tds-titles"> <b>Looking for 5 Bedroom </b> </div>
        <div class="tds-sub-title">In Port Harcourt, Rivers State</div>
        <p class="single-detail">Brand New 5 Bedroom Fully Detached House with BQ
          <br>Brand New 5 Bedroom Fully Detached House with BQ in Osapa;
          <br>Located in a serene and residential area;
          <br>Easily accessible from the Lekki-Epe Expressway way;
          <br>Spacious compound, can take 4cars; Security gatehouse;
          <br>Self-serviced; Borehole with water treatment plant;
          <br>Well finished with P.O.P and vitrified tiles;
          <br>Inbuilt surround speakers;
          <br>Fitted kitchen with Gas burners,heat extractor, microwave, oven, pantry, washing machine and cabinets;
          <br>Ground floor, Living room, Dinning room, Kitchen, Guest room, Visitor’s toilet and BQ;
          <br>First floor;
          <br>Family lounge with 4bedrooms including the Master-bedroom;
          <br>All rooms en suite;
          <br>Sizeable bedrooms with wardrobes and shower cubicles;
          <br>Sale price is N210,000,000
        </p>
      </div>
      <!-- <div style="background:blue;height:300px;"> -->
        <div>
        <div>
          <div class="card">
            <header class="card-header">
              <p class="card-header-title  ">
                Budget: N210,000,000</p>
            </header>
            <div class="card-content">
              <div class="content tds-card-content" align="center">
                <img src="/img/agentavatar.png"/>
                <p>Emmanuel Louis</p>
              </div>
            </div>
            <footer class="card-footer">
              <span>Show contact</span>
            </footer>
          
      </div>
    </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style>

</style>
