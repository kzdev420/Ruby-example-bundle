<template>
  <div>
    <div class="tds-banner-items">
      <img src="/img/Logo.png">
      <div class="tds-title">
        <span>2</span>DOTS
      </div>
      <p>PROPERTIES</p>
      <p class="tds-is-subtitle">FIND YOUR IDEAL HOME OR OFFICE</p>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style>

</style>
