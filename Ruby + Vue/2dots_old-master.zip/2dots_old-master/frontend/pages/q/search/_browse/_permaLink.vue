<template>
  <section class="container">
    <h1>Hello from permalink</h1>
  </section>
</template>

<script>
export default {
created(){
  
}
}
</script>

<style>

</style>
