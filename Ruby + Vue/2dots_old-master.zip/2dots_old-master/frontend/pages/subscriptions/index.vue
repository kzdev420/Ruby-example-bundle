<template>
    <div class="container">
        subscriptions
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
