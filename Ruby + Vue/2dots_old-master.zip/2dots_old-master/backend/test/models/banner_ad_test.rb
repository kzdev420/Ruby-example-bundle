require 'test_helper'

class BannerAdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
