require 'test_helper'

class VerifyUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
