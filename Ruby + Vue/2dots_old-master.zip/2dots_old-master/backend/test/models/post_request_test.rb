require 'test_helper'

class PostRequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
