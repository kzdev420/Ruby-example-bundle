require 'test_helper'

class BannerAdSubscriberControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
