class ApplicationMailer < ActionMailer::Base
  default from: 'no-reply@2dotsproperties.com'
  layout 'mailer'
end
