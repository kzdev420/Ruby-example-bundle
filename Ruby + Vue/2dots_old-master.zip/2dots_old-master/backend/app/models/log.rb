class Log < ApplicationRecord
  belongs_to :user
end
