# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180225172915) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "api_clients", force: :cascade do |t|
    t.string   "fat_agent_id"
    t.string   "api_token"
    t.string   "api_client_id"
    t.string   "api_profile_id"
    t.string   "ip_address"
    t.integer  "api_statistics_id"
    t.boolean  "active"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
    t.integer  "user_id"
  end

  create_table "approval_records", force: :cascade do |t|
    t.text     "carrier_approval_record"
    t.text     "product_group_approval_record"
    t.text     "product_approval_record"
    t.integer  "api_client_id"
    t.datetime "created_at",                    null: false
    t.datetime "updated_at",                    null: false
  end

  create_table "bands", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.string   "band_name"
    t.integer  "face_amount_start"
    t.integer  "face_amount_end"
    t.decimal  "min_premium_annual",               precision: 6, scale: 2, default: "0.0"
    t.decimal  "max_premium_annual",               precision: 6, scale: 2, default: "0.0"
    t.decimal  "min_premium_semi_annual",          precision: 6, scale: 2, default: "0.0"
    t.decimal  "max_premium_semi_annual",          precision: 6, scale: 2, default: "0.0"
    t.decimal  "min_premium_quarterly",            precision: 6, scale: 2, default: "0.0"
    t.decimal  "max_premium_quarterly",            precision: 6, scale: 2, default: "0.0"
    t.decimal  "min_premium_monthly",              precision: 6, scale: 2, default: "0.0"
    t.decimal  "max_premium_monthly",              precision: 6, scale: 2, default: "0.0"
    t.boolean  "round_base_rate_before_modal",                             default: true
    t.boolean  "round_base_rate_after_modal",                              default: true
    t.boolean  "multiply_policy_fee_by_modal",                             default: true
    t.boolean  "round_policy_fee_before_addition",                         default: true
    t.boolean  "round_flat_extra_before_modal",                            default: true
    t.boolean  "round_flat_extra_after_modal",                             default: true
    t.decimal  "policy_fee_annual",                precision: 5, scale: 2, default: "0.0"
    t.decimal  "policy_fee_semi_annual",           precision: 5, scale: 2, default: "0.0"
    t.decimal  "policy_fee_quarterly",             precision: 5, scale: 2, default: "0.0"
    t.decimal  "policy_fee_monthly",               precision: 5, scale: 2, default: "0.0"
    t.boolean  "policy_fee_commissionable"
    t.string   "age_calculation_type"
    t.boolean  "archived",                                                 default: false
    t.boolean  "approved_deleted",                                         default: false
    t.boolean  "deleted",                                                  default: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "base_rate_columns", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.integer  "base_rate_table_id"
    t.integer  "product_id"
    t.integer  "band_id"
    t.integer  "health_category_id"
    t.integer  "table_rate_id"
    t.string   "gender",                        limit: 10
    t.boolean  "tobacco"
    t.string   "col_type",                      limit: 30,                          default: "Normal"
    t.integer  "face_amount_start",                                                 default: 0
    t.integer  "face_amount_end",                                                   default: 0
    t.boolean  "use_quote_table_modal_factors",                                     default: true
    t.integer  "modal_factor_id"
    t.boolean  "use_quote_table_adb_riders",                                        default: true
    t.boolean  "use_quote_table_wop_riders",                                        default: true
    t.boolean  "use_quote_table_child_riders",                                      default: true
    t.decimal  "age_0",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_1",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_2",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_3",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_4",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_5",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_6",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_7",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_8",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_9",                                    precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_10",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_11",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_12",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_13",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_14",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_15",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_16",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_17",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_18",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_19",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_20",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_21",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_22",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_23",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_24",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_25",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_26",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_27",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_28",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_29",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_30",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_31",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_32",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_33",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_34",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_35",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_36",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_37",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_38",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_39",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_40",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_41",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_42",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_43",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_44",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_45",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_46",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_47",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_48",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_49",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_50",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_51",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_52",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_53",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_54",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_55",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_56",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_57",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_58",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_59",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_60",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_61",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_62",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_63",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_64",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_65",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_66",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_67",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_68",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_69",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_70",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_71",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_72",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_73",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_74",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_75",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_76",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_77",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_78",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_79",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_80",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_81",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_82",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_83",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_84",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_85",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_86",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_87",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_88",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_89",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_90",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_91",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_92",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_93",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_94",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_95",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_96",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_97",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_98",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_99",                                   precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_100",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_101",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_102",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_103",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_104",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_105",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_106",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_107",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_108",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_109",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_110",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_111",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_112",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_113",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_114",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_115",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_116",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_117",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_118",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_119",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_120",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_121",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_122",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_123",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_124",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_125",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_126",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_127",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_128",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_129",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_130",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_131",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_132",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_133",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_134",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_135",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_136",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_137",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_138",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_139",                                  precision: 10, scale: 6, default: "0.0"
    t.decimal  "age_140",                                  precision: 10, scale: 6, default: "0.0"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "adb_rider_id"
    t.integer  "child_rider_id"
    t.integer  "wop_rider_id"
  end

  create_table "base_rate_tables", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.integer  "modal_factor_id"
    t.integer  "product_id"
    t.integer  "band_id"
    t.text     "notes"
    t.text     "adb_rider_ids"
    t.text     "wop_rider_ids"
    t.text     "child_rider_ids"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "build_charts", force: :cascade do |t|
    t.integer  "male_5_0_min"
    t.integer  "male_5_1_min"
    t.integer  "male_5_2_min"
    t.integer  "male_5_3_min"
    t.integer  "male_5_4_min"
    t.integer  "male_5_5_min"
    t.integer  "male_5_6_min"
    t.integer  "male_5_7_min"
    t.integer  "male_5_8_min"
    t.integer  "male_5_9_min"
    t.integer  "male_5_10_min"
    t.integer  "male_5_11_min"
    t.integer  "male_6_0_min"
    t.integer  "male_6_1_min"
    t.integer  "male_6_2_min"
    t.integer  "male_6_3_min"
    t.integer  "male_6_4_min"
    t.integer  "male_6_5_min"
    t.integer  "male_5_0_max"
    t.integer  "male_5_1_max"
    t.integer  "male_5_2_max"
    t.integer  "male_5_3_max"
    t.integer  "male_5_4_max"
    t.integer  "male_5_5_max"
    t.integer  "male_5_6_max"
    t.integer  "male_5_7_max"
    t.integer  "male_5_8_max"
    t.integer  "male_5_9_max"
    t.integer  "male_5_10_max"
    t.integer  "male_5_11_max"
    t.integer  "male_6_0_max"
    t.integer  "male_6_1_max"
    t.integer  "male_6_2_max"
    t.integer  "male_6_3_max"
    t.integer  "male_6_4_max"
    t.integer  "male_6_5_max"
    t.integer  "male_6_6_max"
    t.integer  "male_6_7_max"
    t.integer  "male_6_8_max"
    t.integer  "male_6_9_max"
    t.integer  "female_4_6_min"
    t.integer  "female_4_7_min"
    t.integer  "female_4_8_min"
    t.integer  "female_4_9_min"
    t.integer  "female_4_10_min"
    t.integer  "female_4_11_min"
    t.integer  "female_5_0_min"
    t.integer  "female_5_1_min"
    t.integer  "female_5_2_min"
    t.integer  "female_5_3_min"
    t.integer  "female_5_4_min"
    t.integer  "female_5_5_min"
    t.integer  "female_5_6_min"
    t.integer  "female_5_7_min"
    t.integer  "female_5_8_min"
    t.integer  "female_5_9_min"
    t.integer  "female_5_10_min"
    t.integer  "female_5_11_min"
    t.integer  "female_6_0_min"
    t.integer  "female_6_1_min"
    t.integer  "female_6_2_min"
    t.integer  "female_6_3_min"
    t.integer  "female_6_4_min"
    t.integer  "female_6_5_min"
    t.integer  "female_4_6_max"
    t.integer  "female_4_7_max"
    t.integer  "female_4_8_max"
    t.integer  "female_4_9_max"
    t.integer  "female_4_10_max"
    t.integer  "female_4_11_max"
    t.integer  "female_5_0_max"
    t.integer  "female_5_1_max"
    t.integer  "female_5_2_max"
    t.integer  "female_5_3_max"
    t.integer  "female_5_4_max"
    t.integer  "female_5_5_max"
    t.integer  "female_5_6_max"
    t.integer  "female_5_7_max"
    t.integer  "female_5_8_max"
    t.integer  "female_5_9_max"
    t.integer  "female_5_10_max"
    t.integer  "female_5_11_max"
    t.integer  "female_6_0_max"
    t.integer  "female_6_1_max"
    t.integer  "female_6_2_max"
    t.integer  "female_6_3_max"
    t.integer  "female_6_4_max"
    t.integer  "female_6_5_max"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.integer  "carrier_id"
    t.integer  "female_4_5_min"
    t.integer  "female_4_5_max"
    t.integer  "male_6_6_min"
    t.integer  "male_6_7_min"
    t.integer  "male_6_8_min"
    t.integer  "male_6_9_min"
    t.integer  "male_6_10_min"
    t.integer  "male_6_11_min"
    t.integer  "male_6_10_max"
    t.integer  "male_6_11_max"
    t.string   "name"
  end

  create_table "carriers", force: :cascade do |t|
    t.string   "name",            limit: 100
    t.string   "internal_note"
    t.string   "street1",         limit: 100
    t.string   "street2",         limit: 100
    t.string   "city",            limit: 100
    t.string   "state",           limit: 5
    t.string   "zipcode",         limit: 15
    t.string   "phone",           limit: 30
    t.string   "email",           limit: 150
    t.string   "website"
    t.boolean  "compulife_forms",             default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "status"
    t.string   "logo_uploader"
    t.boolean  "quotes_live",                 default: false
    t.boolean  "forms_live",                  default: false
    t.string   "logo"
    t.string   "external_code"
  end

  create_table "data_versions", force: :cascade do |t|
    t.integer  "carrier_id"
    t.string   "data_type",                      limit: 30
    t.string   "token",                          limit: 30
    t.datetime "date_gone_live"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean  "live"
    t.boolean  "band_stage_complete",                       default: false
    t.boolean  "modal_factor_stage_complete",               default: false
    t.boolean  "health_category_stage_complete",            default: false
    t.boolean  "table_rate_stage_complete",                 default: false
    t.boolean  "rider_rate_stage_complete",                 default: false
    t.boolean  "base_rate_table_stage_complete",            default: false
    t.boolean  "audit_stage_complete",                      default: false
    t.string   "processing_pattern"
    t.string   "rate_file"
  end

  create_table "fillable_fields", force: :cascade do |t|
    t.integer  "question_id"
    t.integer  "form_id"
    t.text     "flags"
    t.text     "justification"
    t.text     "name"
    t.text     "name_alt"
    t.text     "field_type"
    t.text     "options"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
  end

  create_table "fips", force: :cascade do |t|
    t.integer  "form_id"
    t.integer  "user_id"
    t.text     "form_structure"
    t.text     "responses"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.string   "name"
    t.string   "file"
  end

  create_table "form_mappings", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "form_id"
    t.integer  "product_group_id"
    t.integer  "carrier_id"
    t.boolean  "state_AL",             default: false
    t.boolean  "state_AK",             default: false
    t.boolean  "state_AS",             default: false
    t.boolean  "state_AZ",             default: false
    t.boolean  "state_AR",             default: false
    t.boolean  "state_CA",             default: false
    t.boolean  "state_CO",             default: false
    t.boolean  "state_CT",             default: false
    t.boolean  "state_DE",             default: false
    t.boolean  "state_DC",             default: false
    t.boolean  "state_FM",             default: false
    t.boolean  "state_FL",             default: false
    t.boolean  "state_GA",             default: false
    t.boolean  "state_GU",             default: false
    t.boolean  "state_HI",             default: false
    t.boolean  "state_ID",             default: false
    t.boolean  "state_IL",             default: false
    t.boolean  "state_IN",             default: false
    t.boolean  "state_IA",             default: false
    t.boolean  "state_KS",             default: false
    t.boolean  "state_KY",             default: false
    t.boolean  "state_LA",             default: false
    t.boolean  "state_ME",             default: false
    t.boolean  "state_MH",             default: false
    t.boolean  "state_MD",             default: false
    t.boolean  "state_MA",             default: false
    t.boolean  "state_MI",             default: false
    t.boolean  "state_MN",             default: false
    t.boolean  "state_MS",             default: false
    t.boolean  "state_MO",             default: false
    t.boolean  "state_MT",             default: false
    t.boolean  "state_NE",             default: false
    t.boolean  "state_NV",             default: false
    t.boolean  "state_NH",             default: false
    t.boolean  "state_NJ",             default: false
    t.boolean  "state_NM",             default: false
    t.boolean  "state_NY",             default: false
    t.boolean  "state_NC",             default: false
    t.boolean  "state_ND",             default: false
    t.boolean  "state_MP",             default: false
    t.boolean  "state_OH",             default: false
    t.boolean  "state_OK",             default: false
    t.boolean  "state_OR",             default: false
    t.boolean  "state_PW",             default: false
    t.boolean  "state_PA",             default: false
    t.boolean  "state_PR",             default: false
    t.boolean  "state_RI",             default: false
    t.boolean  "state_SC",             default: false
    t.boolean  "state_SD",             default: false
    t.boolean  "state_TN",             default: false
    t.boolean  "state_TX",             default: false
    t.boolean  "state_UT",             default: false
    t.boolean  "state_VT",             default: false
    t.boolean  "state_VI",             default: false
    t.boolean  "state_VA",             default: false
    t.boolean  "state_WA",             default: false
    t.boolean  "state_WV",             default: false
    t.boolean  "state_WI",             default: false
    t.boolean  "state_WY",             default: false
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.boolean  "new_business"
    t.boolean  "policyholder_service"
    t.boolean  "marketing"
    t.boolean  "contracting"
  end

  create_table "form_packets", force: :cascade do |t|
    t.integer  "carrier_id"
    t.integer  "product_group_id"
    t.integer  "data_version_id"
    t.text     "packet_type"
    t.text     "state"
    t.text     "file"
    t.text     "name"
    t.datetime "created_at",       null: false
    t.datetime "updated_at",       null: false
  end

  create_table "forms", force: :cascade do |t|
    t.integer  "data_version_id"
    t.string   "form_name"
    t.string   "form_number"
    t.string   "form_date"
    t.text     "description"
    t.text     "notes"
    t.integer  "carrier_id"
    t.datetime "file_upload_date"
    t.integer  "file_size",        default: 0
    t.boolean  "active",           default: false
    t.datetime "created_at",                       null: false
    t.datetime "updated_at",                       null: false
    t.string   "file"
    t.text     "guid"
  end

  create_table "health_categories", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.string   "fat_quote_health_category"
    t.string   "carrier_health_category"
    t.string   "tobacco_category_type",     limit: 15, default: "Both"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "table_rate_id"
    t.integer  "build_chart_id"
  end

  create_table "modal_factors", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.string   "name",                   limit: 100
    t.decimal  "annual_factor",                      precision: 12, scale: 8, default: "0.0"
    t.decimal  "semi_annual_factor",                 precision: 12, scale: 8, default: "0.0"
    t.decimal  "quarterly_factor",                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "monthly_factor",                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "annual_factor_fee",                  precision: 12, scale: 8, default: "0.0"
    t.decimal  "semi_annual_factor_fee",             precision: 12, scale: 8, default: "0.0"
    t.decimal  "quarterly_factor_fee",               precision: 12, scale: 8, default: "0.0"
    t.decimal  "monthly_factor_fee",                 precision: 12, scale: 8, default: "0.0"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "product_groups", force: :cascade do |t|
    t.integer  "carrier_id"
    t.string   "group_name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "state_approval_id"
  end

  create_table "products", force: :cascade do |t|
    t.integer  "product_group_id"
    t.string   "product_name"
    t.string   "line_of_coverage"
    t.string   "product_line",             limit: 50
    t.string   "product_line_detail",      limit: 50
    t.text     "agent_message"
    t.text     "consumer_message"
    t.integer  "carrier_id"
    t.string   "client_brochure_url1"
    t.string   "client_brochure_url2"
    t.string   "client_brochure_url3"
    t.string   "agent_guide_url1"
    t.string   "agent_guide_url2"
    t.string   "agent_guide_url3"
    t.string   "product_description"
    t.string   "quote_notice"
    t.string   "quote_note"
    t.boolean  "use_product_group_states",            default: true
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "state_approval_id"
  end

  create_table "questions", force: :cascade do |t|
    t.integer  "section_id"
    t.text     "text"
    t.text     "help_text"
    t.text     "question_type"
    t.text     "number"
    t.decimal  "order"
    t.text     "fillable_id"
    t.text     "identifier"
    t.boolean  "required"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.string   "options"
    t.integer  "form_id"
    t.decimal  "row"
    t.integer  "column"
    t.string   "table_id"
  end

  create_table "quote_results", force: :cascade do |t|
    t.integer  "quote_id"
    t.integer  "company_id"
    t.datetime "created_at",                      null: false
    t.datetime "updated_at",                      null: false
    t.string   "company"
    t.string   "product"
    t.decimal  "face_amount"
    t.decimal  "base_rate"
    t.decimal  "annual_policy_base"
    t.decimal  "annual_policy_fee"
    t.decimal  "annual_policy_child_rider"
    t.decimal  "annual_policy_wop_rider"
    t.decimal  "annual_policy_adb_rider"
    t.decimal  "annual_policy_table_rating"
    t.decimal  "annual_policy_total"
    t.decimal  "semi_annual_policy_base"
    t.decimal  "semi_annual_policy_fee"
    t.decimal  "semi_annual_policy_child_rider"
    t.decimal  "semi_annual_policy_wop_rider"
    t.decimal  "semi_annual_policy_adb_rider"
    t.decimal  "semi_annual_policy_table_rating"
    t.decimal  "semi_annual_policy_total"
    t.decimal  "quarterly_policy_base"
    t.decimal  "quarterly_policy_fee"
    t.decimal  "quarterly_policy_child_rider"
    t.decimal  "quarterly_policy_wop_rider"
    t.decimal  "quarterly_policy_adb_rider"
    t.decimal  "quarterly_policy_table_rating"
    t.decimal  "quarterly_policy_total"
    t.decimal  "monthly_policy_base"
    t.decimal  "monthly_policy_fee"
    t.decimal  "monthly_policy_child_rider"
    t.decimal  "monthly_policy_wop_rider"
    t.decimal  "monthly_policy_adb_rider"
    t.decimal  "monthly_policy_table_rating"
    t.decimal  "monthly_policy_total"
    t.boolean  "has_marketing_forms"
    t.boolean  "has_application_forms"
    t.integer  "quote_age"
    t.string   "age_type"
    t.decimal  "annual_target_premium"
    t.decimal  "semi_annual_target_premium"
    t.decimal  "quarterly_target_premium"
    t.decimal  "monthly_target_premium"
    t.string   "health_category"
    t.string   "health_category_type"
    t.integer  "product_id"
    t.string   "carrier_logo"
    t.integer  "health_category_id"
    t.decimal  "annual_policy_flat_extra"
    t.decimal  "semi_annual_policy_flat_extra"
    t.decimal  "quarterly_policy_flat_extra"
    t.decimal  "monthly_policy_flat_extra"
  end

  create_table "quotes", force: :cascade do |t|
    t.text     "quote_parameters"
    t.integer  "api_client_id"
    t.integer  "quote_views"
    t.integer  "client_id"
    t.datetime "created_at",         null: false
    t.datetime "updated_at",         null: false
    t.text     "quote_results_data"
  end

  create_table "rider_rates", force: :cascade do |t|
    t.integer  "data_version_id"
    t.integer  "carrier_id"
    t.string   "name",                           limit: 50
    t.string   "rider_type",                     limit: 30
    t.text     "product_ids"
    t.text     "band_ids"
    t.text     "health_category_ids"
    t.string   "gender",                         limit: 10
    t.string   "tobacco",                        limit: 20
    t.integer  "age_start",                                                          default: 18
    t.integer  "age_end",                                                            default: 75
    t.integer  "face_amount_start",                                                  default: 0
    t.integer  "face_amount_end",                                                    default: 0
    t.string   "lowest_table_rate",              limit: 4
    t.decimal  "max_flat_extra",                            precision: 8,  scale: 6, default: "0.0"
    t.string   "calc_type",                      limit: 40
    t.string   "benefit_coverage_calc_type",     limit: 40
    t.integer  "min_benefit_coverage",                                               default: 0
    t.integer  "max_benefit_coverage",                                               default: 0
    t.integer  "min_units",                                                          default: 0
    t.integer  "max_units",                                                          default: 10
    t.integer  "coverage_per_unit",                                                  default: 1000
    t.decimal  "child_wop_unit_extra_premium",              precision: 8,  scale: 6, default: "0.0"
    t.decimal  "child_table_rate_extra_premium",            precision: 8,  scale: 6, default: "0.0"
    t.integer  "modal_factor_id"
    t.boolean  "round_before_modal",                                                 default: false
    t.boolean  "round_after_modal",                                                  default: true
    t.decimal  "age_0",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_1",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_2",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_3",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_4",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_5",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_6",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_7",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_8",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_9",                                     precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_10",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_11",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_12",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_13",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_14",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_15",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_16",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_17",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_18",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_19",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_20",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_21",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_22",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_23",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_24",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_25",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_26",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_27",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_28",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_29",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_30",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_31",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_32",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_33",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_34",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_35",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_36",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_37",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_38",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_39",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_40",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_41",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_42",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_43",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_44",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_45",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_46",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_47",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_48",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_49",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_50",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_51",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_52",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_53",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_54",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_55",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_56",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_57",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_58",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_59",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_60",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_61",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_62",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_63",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_64",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_65",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_66",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_67",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_68",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_69",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_70",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_71",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_72",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_73",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_74",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_75",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_76",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_77",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_78",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_79",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_80",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_81",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_82",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_83",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_84",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_85",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_86",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_87",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_88",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_89",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_90",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_91",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_92",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_93",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_94",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_95",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_96",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_97",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_98",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_99",                                    precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_100",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_101",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_102",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_103",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_104",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_105",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_106",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_107",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_108",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_109",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_110",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_111",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_112",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_113",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_114",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_115",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_116",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_117",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_118",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_119",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_120",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_121",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_122",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_123",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_124",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_125",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_126",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_127",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_128",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_129",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_130",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_131",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_132",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_133",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_134",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_135",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_136",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_137",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_138",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_139",                                   precision: 12, scale: 8, default: "0.0"
    t.decimal  "age_140",                                   precision: 12, scale: 8, default: "0.0"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sections", force: :cascade do |t|
    t.integer  "form_id"
    t.text     "title"
    t.text     "subtitle"
    t.text     "number"
    t.decimal  "order"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "state_approvals", force: :cascade do |t|
    t.integer  "parent_state_approval_id"
    t.boolean  "use_parent_state_approvals", default: false
    t.boolean  "state_AL",                   default: false
    t.boolean  "state_AK",                   default: false
    t.boolean  "state_AS",                   default: false
    t.boolean  "state_AZ",                   default: false
    t.boolean  "state_AR",                   default: false
    t.boolean  "state_CA",                   default: false
    t.boolean  "state_CO",                   default: false
    t.boolean  "state_CT",                   default: false
    t.boolean  "state_DE",                   default: false
    t.boolean  "state_DC",                   default: false
    t.boolean  "state_FM",                   default: false
    t.boolean  "state_FL",                   default: false
    t.boolean  "state_GA",                   default: false
    t.boolean  "state_GU",                   default: false
    t.boolean  "state_HI",                   default: false
    t.boolean  "state_ID",                   default: false
    t.boolean  "state_IL",                   default: false
    t.boolean  "state_IN",                   default: false
    t.boolean  "state_IA",                   default: false
    t.boolean  "state_KS",                   default: false
    t.boolean  "state_KY",                   default: false
    t.boolean  "state_LA",                   default: false
    t.boolean  "state_ME",                   default: false
    t.boolean  "state_MH",                   default: false
    t.boolean  "state_MD",                   default: false
    t.boolean  "state_MA",                   default: false
    t.boolean  "state_MI",                   default: false
    t.boolean  "state_MN",                   default: false
    t.boolean  "state_MS",                   default: false
    t.boolean  "state_MO",                   default: false
    t.boolean  "state_MT",                   default: false
    t.boolean  "state_NE",                   default: false
    t.boolean  "state_NV",                   default: false
    t.boolean  "state_NH",                   default: false
    t.boolean  "state_NJ",                   default: false
    t.boolean  "state_NM",                   default: false
    t.boolean  "state_NY",                   default: false
    t.boolean  "state_NC",                   default: false
    t.boolean  "state_ND",                   default: false
    t.boolean  "state_MP",                   default: false
    t.boolean  "state_OH",                   default: false
    t.boolean  "state_OK",                   default: false
    t.boolean  "state_OR",                   default: false
    t.boolean  "state_PW",                   default: false
    t.boolean  "state_PA",                   default: false
    t.boolean  "state_PR",                   default: false
    t.boolean  "state_RI",                   default: false
    t.boolean  "state_SC",                   default: false
    t.boolean  "state_SD",                   default: false
    t.boolean  "state_TN",                   default: false
    t.boolean  "state_TX",                   default: false
    t.boolean  "state_UT",                   default: false
    t.boolean  "state_VT",                   default: false
    t.boolean  "state_VI",                   default: false
    t.boolean  "state_VA",                   default: false
    t.boolean  "state_WA",                   default: false
    t.boolean  "state_WV",                   default: false
    t.boolean  "state_WI",                   default: false
    t.boolean  "state_WY",                   default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "product_group_id"
    t.integer  "product_id"
  end

  create_table "table_rates", force: :cascade do |t|
    t.integer  "carrier_id"
    t.integer  "data_version_id"
    t.string   "name",            limit: 100
    t.string   "calc_type",       limit: 50,                          default: "standard"
    t.boolean  "round_rate",                                          default: true
    t.integer  "min_face_amount",                                     default: 0
    t.integer  "max_face_amount",                                     default: 0
    t.boolean  "wop_applied",                                         default: false
    t.boolean  "adb_applied",                                         default: false
    t.boolean  "cir_applied",                                         default: false
    t.boolean  "table_A",                                             default: true
    t.boolean  "table_B",                                             default: true
    t.boolean  "table_C",                                             default: true
    t.boolean  "table_D",                                             default: true
    t.boolean  "table_E",                                             default: true
    t.boolean  "table_F",                                             default: true
    t.boolean  "table_G",                                             default: true
    t.boolean  "table_H",                                             default: true
    t.boolean  "table_I",                                             default: false
    t.boolean  "table_J",                                             default: false
    t.boolean  "table_K",                                             default: false
    t.boolean  "table_L",                                             default: false
    t.boolean  "table_M",                                             default: false
    t.boolean  "table_N",                                             default: false
    t.boolean  "table_O",                                             default: false
    t.boolean  "table_P",                                             default: false
    t.decimal  "table_A_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_B_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_C_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_D_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_E_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_F_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_G_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_H_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_I_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_J_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_K_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_L_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_M_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_N_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_O_percent",             precision: 6, scale: 3, default: "0.0"
    t.decimal  "table_P_percent",             precision: 6, scale: 3, default: "0.0"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", force: :cascade do |t|
    t.string   "email",                  default: "", null: false
    t.string   "encrypted_password",     default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0,  null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet     "current_sign_in_ip"
    t.inet     "last_sign_in_ip"
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.string   "name"
    t.index ["email"], name: "index_users_on_email", unique: true, using: :btree
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree
  end

end
