class ChangeColType < ActiveRecord::Migration[5.0]
  def change
  	change_column :questions, :column, :integer
  end
end
