class AddRowColToQuestion < ActiveRecord::Migration[5.0]
  def change
  	add_column :questions, :row, :decimal
  	add_column :questions, :column, :decimal
  	add_column :questions, :table_id, :string
  end
end
