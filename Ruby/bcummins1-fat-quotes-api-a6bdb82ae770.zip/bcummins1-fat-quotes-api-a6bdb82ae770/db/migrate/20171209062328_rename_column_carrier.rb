class RenameColumnCarrier < ActiveRecord::Migration[5.0]
  def change
	    rename_column :carriers, :compulife_code, :external_code
  end
end
