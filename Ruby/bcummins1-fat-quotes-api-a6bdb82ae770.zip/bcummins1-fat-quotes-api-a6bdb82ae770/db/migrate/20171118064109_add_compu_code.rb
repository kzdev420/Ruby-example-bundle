class AddCompuCode < ActiveRecord::Migration[5.0]
  def change
    add_column :carriers, :compulife_code, :string

  end
end
