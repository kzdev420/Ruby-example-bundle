class Fip < ActiveRecord::Migration[5.0]
  def change
  	create_table "fips", force: :cascade do |t|
	    t.integer       "form_id"
	    t.integer       "user_id"
	    t.text     		"form_structure", :limit => 42949672
	    t.text 			"responses", 	  :limit => 42949672
	    t.datetime "created_at",                    null: false
	    t.datetime "updated_at",                    null: false
	 end
  end
end
