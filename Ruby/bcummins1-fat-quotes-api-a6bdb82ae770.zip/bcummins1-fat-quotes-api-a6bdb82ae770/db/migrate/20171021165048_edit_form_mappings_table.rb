class EditFormMappingsTable < ActiveRecord::Migration[5.0]
  def change
    	remove_column :form_mappings, :required_form
    	remove_column :form_mappings, :order_priority
    	add_column :form_mappings, :new_business, :boolean
    	add_column :form_mappings, :policyholder_service, :boolean
    	add_column :form_mappings, :marketing, :boolean
    	add_column :form_mappings, :contracting, :boolean
  end
end
