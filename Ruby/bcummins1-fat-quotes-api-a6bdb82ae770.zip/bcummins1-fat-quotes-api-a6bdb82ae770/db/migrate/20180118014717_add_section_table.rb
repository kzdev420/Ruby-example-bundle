class AddSectionTable < ActiveRecord::Migration[5.0]
  def change
  	create_table "sections", force: :cascade do |t|
	    t.integer       "form_id"
	    t.text     		"title"
	    t.text 			"subtitle"
	    t.text 			"number"
	    t.decimal  		"order"
	    t.datetime "created_at",                    null: false
	    t.datetime "updated_at",                    null: false
	 end
	 create_table "questions", force: :cascade do |t|
	    t.integer       "section_id"
	    t.text     		"text"
	    t.text			"help_text"
	    t.text 			"question_type"
	    t.text			"number"
	    t.decimal		"order"
	    t.text  		"fillable_id"
	    t.text			"identifier"
	    t.boolean		"required"
	    t.datetime "created_at",                    null: false
	    t.datetime "updated_at",                    null: false
	 end
  end
end
