class HealthCategorySerializer < ActiveModel::Serializer
  attributes :id, :fat_quote_health_category, :carrier_health_category, :build_chart, :table_rate

  def build_chart
  	if @object.build_chart_id.nil?
  		return "There is no build chart related to this health category."
  		
  	end
  	@bc = BuildChart.find(@object.build_chart_id)
  	@bcInfo = 
  	{   
  		"id"  =>  @bc.id,
  		"name" => @bc.name,
  		"male" => {},
  		"female" => {},
  	}
  	BUILD_CHART_HEIGHT_WEIGHT_MALE.each do |build_chart_info|
  		next if @bc[build_chart_info[1]].nil?
  		@bcInfo["male"][build_chart_info[2]] = {}
  		@bcInfo["male"][build_chart_info[2]]["minimum"] = @bc[build_chart_info[0]]
  		@bcInfo["male"][build_chart_info[2]]["maximum"] = @bc[build_chart_info[1]]
  	end
  	BUILD_CHART_HEIGHT_WEIGHT_FEMALE.each do |build_chart_info|
  		next if @bc[build_chart_info[1]].nil?
  		@bcInfo["female"][build_chart_info[2]] = {}
  		@bcInfo["female"][build_chart_info[2]]["minimum"] = @bc[build_chart_info[0]]
  		@bcInfo["female"][build_chart_info[2]]["maximum"] = @bc[build_chart_info[1]]
  	end
  	@bcInfo
  end

  def table_rate
  	if @object.table_rate_id.nil?
  		return "There is no table rating related to this health category."
  	end
  	@tr = TableRate.find(@object.table_rate_id)
  	@trInfo = 
  	{
  		"name" => @tr.name
  	}
  	["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"].each do |letter|
  		if @tr["table_#{letter}"] == true
  			@trInfo["table_#{letter}"] = @tr["table_#{letter}_percent"].to_f / 100
  		end
  	end
  	@trInfo
  end

end
