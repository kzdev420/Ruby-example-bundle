class ProductSerializer < ActiveModel::Serializer
  attributes :id, :product_name, :line_of_coverage, :product_line, :product_line_detail, :state_approvals

  def state_approvals
    if @object.state_approval.nil?
      return "There is no state approval related to this health category."
    end
    return @object.state_approval
  end
end
