class ProductGroupSerializer < ActiveModel::Serializer
  attributes :id, :carrier_id, :group_name, :state_approvals

  def state_approvals
    if @object.state_approval.nil?
      return "There is no state approval related to this health category."
    end
    return @object.state_approval
  end
end
