class ApprovalRecord < ApplicationRecord
	belongs_to :api_client
end
