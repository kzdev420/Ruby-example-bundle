class StateApproval < ApplicationRecord
	belongs_to :product_group, optional: true
	belongs_to :product, optional: true

	def reset_state_approval(state_list)
		STATE_TO_ABBR_ARRAY.each do |state|
      self["state_#{state[1]}"] = false
    end
    PROVINCES_TO_ABBR_ARRAY.each do |state|
      self["state_#{state[1]}"] = false
    end
    state_list.each do |state|
        self["state_#{state}"] = true
      end
		self.save
	end
end
