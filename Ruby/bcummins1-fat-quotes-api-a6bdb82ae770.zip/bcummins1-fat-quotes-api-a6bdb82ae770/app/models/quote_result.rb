class QuoteResult < ApplicationRecord
	belongs_to :quote

	def get_application_forms (quote_params, product_group)
		forms = {}
		forms["required"] = []
		forms["supplemental"] = []
		@data_version_id = DataVersion.where(:carrier_id => product_group.carrier_id, :data_type => "forms", :live => true).first.id
		FormMapping.where(:product_group_id => product_group.id, :data_version_id => @data_version_id, "state_#{quote_params['state']}" => true).order("order_priority ASC").each do |fm|
			form = {}
			form["form_name"] = fm.form.form_name
			form["form_number"] = fm.form.form_number
			form["thumbnail_url"] = fm.form.file.versions[:thumb].url
			form["pdf_url"] = fm.form.file.url
			fm.required_form ? forms["required"] << form : forms["supplemental"] << form 
		end
		return forms
	end
end
