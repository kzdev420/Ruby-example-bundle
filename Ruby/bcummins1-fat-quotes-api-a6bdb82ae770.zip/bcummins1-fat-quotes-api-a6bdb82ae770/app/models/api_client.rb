class ApiClient < ApplicationRecord
	has_one :approval_record, dependent: :destroy
	belongs_to :user, optional: true
	has_many :quotes, dependent: :destroy
end
