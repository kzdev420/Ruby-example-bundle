class Quote < ApplicationRecord
	belongs_to :api_client
	has_many :quote_results, dependent: :destroy

	def get_base_rate_columns(api_client, quoting_params)
		#Get the carriers that this API client is approved for
		@carrier_approvals = JSON.parse(api_client.approval_record.carrier_approval_record).map {|c_id| c_id.to_i}
		#Get the products that the approved carriers have that match the product line detail
		@product_ids = Product.where(:carrier_id => @carrier_approvals, :product_line_detail => quoting_params[:ptd]).ids
		
		#Get the current data versions for the carriers that have been approved and that is alive.
		@current_carrier_version_ids = DataVersion.where(:carrier_id => @carrier_approvals, :live => true).ids
		
		#bands
		@band_ids = Band.where(:data_version_id => @current_carrier_version_ids, :face_amount_start => 0..quoting_params[:amount], :face_amount_end => quoting_params[:amount]..Float::INFINITY).ids
		
		#health categories
		@fat_quote_possible_hcs = FAT_QUOTE_HEALTH_CATEGORIES[FAT_QUOTE_HEALTH_CATEGORIES.index(quoting_params[:health_category])..(FAT_QUOTE_HEALTH_CATEGORIES.size - 1)]
		@health_category_ids = HealthCategory.where(:data_version_id => @current_carrier_version_ids, :fat_quote_health_category => @fat_quote_possible_hcs, :tobacco_category_type => (quoting_params[:tobacco].downcase == "yes" ? "Tobacco" : "Non Tobacco")).ids
		
		@base_rate_columns = BaseRateColumn.where(:product_id => @product_ids, :band_id => @band_ids, :health_category_id => @health_category_ids, :gender => quoting_params[:gender] )
		if quoting_params[:child_rider] == "true"
			@base_rate_columns = @base_rate_columns.where.not(:child_rider_id => nil)
		end

		if quoting_params[:wop_rider] == "true"
			@base_rate_columns = @base_rate_columns.where.not(:wop_rider_id => nil)
		end

		if quoting_params[:adb_rider] == "true"
			@base_rate_columns = @base_rate_columns.where.not(:adb_rider_id => nil)
		end

		if quoting_params[:table_rating] != nil
			@base_rate_columns = @base_rate_columns.where.not(:table_rate_id => nil)
		end
		@base_rate_columns
	end
end
