class Carrier < ApplicationRecord
	has_many :product_groups, dependent: :destroy
	has_many :products, dependent: :destroy
	has_many :build_charts, dependent: :destroy
	mount_uploader :logo, LogoUploader
end
