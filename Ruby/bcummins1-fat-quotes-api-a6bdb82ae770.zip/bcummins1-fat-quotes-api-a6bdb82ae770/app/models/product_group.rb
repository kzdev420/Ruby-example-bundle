class ProductGroup < ApplicationRecord
	belongs_to :carrier
	has_many :products, dependent: :destroy
	has_one :state_approval, dependent: :destroy
end
