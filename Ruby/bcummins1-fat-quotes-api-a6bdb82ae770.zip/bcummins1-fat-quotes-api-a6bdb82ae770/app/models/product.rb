class Product < ApplicationRecord
	belongs_to :carrier
	belongs_to :product_group
	has_one :state_approval
end
