class BaseRateTable < ApplicationRecord
	belongs_to :data_version
	has_many :base_rate_columns, dependent: :destroy

	def update_base_rate_columns
		base_rate_columns.each do |brc|
			brc.update(:product_id => product_id, :modal_factor_id => modal_factor_id, :band_id => band_id)
		end
	end
end
