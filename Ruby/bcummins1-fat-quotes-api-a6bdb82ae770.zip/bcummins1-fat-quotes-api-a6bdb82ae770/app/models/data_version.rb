require 'logger'

class DataVersion < ApplicationRecord
	belongs_to :carrier
	has_many :bands, dependent: :destroy
	has_many :modal_factors, dependent: :destroy
	has_many :health_categories, dependent: :destroy
	has_many :table_rates, dependent: :destroy
	has_many :rider_rates, dependent: :destroy
	has_many :base_rate_tables, dependent: :destroy
	mount_uploader :rate_file, ::RateFileUploader

	def download_forms_from_compulife
		@carrier = Carrier.find(self.carrier_id)
		log = Logger.new("log/" + @carrier.name + '-formsDownload.txt')
		log.debug "Log file created"
		@forms = Form.where(:data_version_id => self.id, :file => nil)
		
		@forms.each do |form|
			begin
				if !@carrier.external_code.nil?
					form.remote_file_url = "http://compulife.us/FORMS/#{@carrier.external_code}/#{form.form_number}.pdf" 
					if form.save!
						log.info "-----------SUCCESS-----Downloaded Form ID: #{form.id}-----------------------"
					else
						log.error "---------------FAILURE---------------COULD NOT DOWNLOAD FORM ID: #{form.id}"
					end
				end
			rescue Exception => e
				log.error "---------------FAILURE---------------COULD NOT DOWNLOAD FORM ID: #{form.id}"
				next
			end
			
			begin
				
			rescue Exception => e
				
			end
		end
	end

end
