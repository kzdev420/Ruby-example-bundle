class Question < ApplicationRecord
	belongs_to :section, optional: true
	has_one :fillable_field


end
