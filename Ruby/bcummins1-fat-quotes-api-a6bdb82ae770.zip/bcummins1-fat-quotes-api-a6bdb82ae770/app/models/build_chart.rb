class BuildChart < ApplicationRecord
	belongs_to :carrier
end
