class Section < ApplicationRecord
	belongs_to :form
	has_many :questions

	def ordered_questions
    	questions.order(:order)
  	end
end
