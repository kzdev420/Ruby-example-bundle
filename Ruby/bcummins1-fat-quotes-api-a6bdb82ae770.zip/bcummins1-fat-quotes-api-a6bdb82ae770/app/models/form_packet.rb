class FormPacket < ApplicationRecord
	mount_uploader :file, ::FormPacketUploader
end
