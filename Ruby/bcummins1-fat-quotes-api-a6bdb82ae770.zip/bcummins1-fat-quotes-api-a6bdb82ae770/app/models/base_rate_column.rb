class BaseRateColumn < ApplicationRecord
	belongs_to :base_rate_table
	def assign_column_riders
		#We have to match on Bands, Product, Health Category, Gender, Tobacco
		#If all of those match, then we are able to add the rider id to the band column rider id
		@child_riders = RiderRate.where(:data_version_id => data_version_id, :rider_type => "child")
		@wop_riders = RiderRate.where(:data_version_id => data_version_id, :rider_type => "wop")
		@adb_riders = RiderRate.where(:data_version_id => data_version_id, :rider_type => "adb")
		brc_specs = {:band_id => band_id, :product_id => product_id, :health_category_id => health_category_id, :gender => gender, :tobacco => tobacco}
		

		[@child_riders, @wop_riders, @adb_riders].each do |rider_set|
			rider_set.each do |rider|
				band_ids_match = JSON.parse(rider.band_ids).include?(band_id)
				product_ids_match = JSON.parse(rider.product_ids).include?(product_id)
				health_category_ids_match = JSON.parse(rider.health_category_ids).include?(health_category_id)
				gender_match = rider.gender == "Both" || rider.gender == gender
				tobacco_match = rider.tobacco == "Both" || ((rider.tobacco == "NonTobacco" && !tobacco) || ((rider.tobacco == "Tobacco") && tobacco))
				if band_ids_match && product_ids_match && health_category_ids_match && gender_match && tobacco_match
					self.wop_rider_id = rider.id
					save
				end
			end
		end
		
	end

	def run_quote(quoting_params)
		quote_result = {}
		@band = Band.find(self.band_id)
		@modal_factor = ModalFactor.find(self.modal_factor_id)
		@carrier = Carrier.find(self.carrier_id)
		@health_category = HealthCategory.find(self.health_category_id)
		@product = Product.find(self.product_id)
		quote_result["company"] = @carrier.name
		quote_result["company_id"] = @carrier.id
		quote_result["product"] = @product.product_name
		quote_result["product_id"] = @product.id
		quote_result["carrier_logo"] = @carrier.logo.url
		quote_result["face_amount"] = quoting_params[:amount]
		quote_result["age_type"] = @band.age_calculation_type
		quote_result["health_category"] = @health_category.fat_quote_health_category
		quote_result["health_category_type"] = @health_category.carrier_health_category
		quote_result["health_category_id"] = @health_category.id
		quote_result["quote_age"] = quote_result["age_type"] == "actual_age" ? quoting_params[:age] : quoting_params[:age_nearest]
		quote_result["base_rate"] = self["age_#{quote_result['quote_age']}"].to_f
		quote_result["annual_policy_base"] = (quote_result["base_rate"] * (quote_result["face_amount"]/1000).round(2)).round(2).to_f
		return if quote_result["base_rate"] == 0.0
		["annual", "semi_annual", "quarterly", "monthly"].each do |mode|
			next if @modal_factor["#{mode}_factor"] == 0.00
			quote_result["#{mode}_policy_fee"] = @band["policy_fee_#{mode}"].to_f
			quote_result["#{mode}_policy_total"] = ((quote_result["annual_policy_base"] * @modal_factor["#{mode}_factor"]) + quote_result["#{mode}_policy_fee"]).round(2)
			quote_result["#{mode}_target_premium"] = @band.policy_fee_commissionable ? quote_result["#{mode}_policy_total"] : quote_result["#{mode}_policy_total"] - quote_result["#{mode}_policy_fee"]
			set_riders_and_ratings(quoting_params)
			if @child_rider.present?
				quote_result["#{mode}_policy_child_rider"] = calculate_child_rider(quoting_params, mode).round(2)
				quote_result["#{mode}_policy_total"] += quote_result["#{mode}_policy_child_rider"].round(2)
			end
			if @wop_rider.present?
				quote_result["#{mode}_policy_wop_rider"] = calculate_wop_rider(quoting_params, mode).round(2)
				quote_result["#{mode}_policy_total"] += quote_result["#{mode}_policy_wop_rider"].round(2)
			end
			if @adb_rider.present?
				quote_result["#{mode}_policy_adb_rider"] = calculate_adb_rider(quoting_params, mode).round(2)
				quote_result["#{mode}_policy_total"] += quote_result["#{mode}_policy_adb_rider"].round(2)
			end
			if @table_rating.present?
				quote_result["#{mode}_policy_table_rating"] = calculate_table_rating(quoting_params, mode, quote_result["annual_policy_base"], @modal_factor["#{mode}_factor"], @table_rating).round(2)
				quote_result["#{mode}_policy_total"] += quote_result["#{mode}_policy_table_rating"].round(2)
			end
			if @flat_extra
				quote_result["#{mode}_policy_flat_extra"] =  ((quoting_params[:flat_extra].to_f * (quote_result["face_amount"]/1000)) * @modal_factor["#{mode}_factor"]).round(2)
				quote_result["#{mode}_policy_total"] += quote_result["#{mode}_policy_flat_extra"]
			end
			quote_result["#{mode}_policy_total"] = quote_result["#{mode}_policy_total"].round(2)
		end
		quote_result
		
	end

	def get_column_premiums(riders)
		premiums = {}
		band = Band.find(self.band_id)
		@modal_factor = ModalFactor.find(self.modal_factor_id)
		face_amount = band.face_amount_start
		quoting_params = {:child_rider => riders.include?("Child"), :wop_rider => riders.include?("Waiver of Premium"), :adb_rider => riders.include?("Accidental Death Benefit"), :face_amount => face_amount, :child_rider_units => 5}
		set_riders_and_ratings(quoting_params)
		0.upto(100).each do |age|
			premiums[age] = {}
			quoting_params[:age] = age
			next if self["age_#{age}"] == 0.0
			["annual", "semi_annual", "quarterly", "monthly"].each do |mode|
				next if @modal_factor["#{mode}_factor"] == 0.00
				premiums[age][mode] = {}
				premiums[age][mode]["base_rate"] = self["age_#{age}"].to_f
				premiums[age][mode]["#{mode}_policy_base"] = ((premiums[age][mode]["base_rate"] * (face_amount/1000).round(2)) * @modal_factor["#{mode}_factor"]) .round(2).to_f
				premiums[age][mode]["#{mode}_policy_fee"] = band["policy_fee_#{mode}"].to_f
				premiums[age][mode]["#{mode}_policy_total"] = premiums[age][mode]["#{mode}_policy_base"] + premiums[age][mode]["#{mode}_policy_fee"]
				premiums[age][mode]["#{mode}_target_premium"] = band.policy_fee_commissionable ? premiums[age][mode]["#{mode}_policy_total"] : premiums[age][mode]["#{mode}_policy_total"] - premiums[age][mode]["#{mode}_policy_fee"]
				if @child_rider.present?
					premiums[age][mode]["#{mode}_policy_child_rider"] = calculate_child_rider(quoting_params, mode)
					premiums[age][mode]["#{mode}_policy_total"] += premiums[age][mode]["#{mode}_policy_child_rider"]
				end
				if @wop_rider.present?
					premiums[age][mode]["#{mode}_policy_wop_rider"] = calculate_wop_rider(quoting_params, mode)
					premiums[age][mode]["#{mode}_policy_total"] += premiums[age][mode]["#{mode}_policy_wop_rider"]
				end
				if @adb_rider.present?
					premiums[age][mode]["#{mode}_policy_adb_rider"] = calculate_adb_rider(quoting_params, mode)
					premiums[age][mode]["#{mode}_policy_total"] += premiums[age][mode]["#{mode}_policy_adb_rider"]
				end
				if @table_rating.present?
					premiums[age][mode]["#{mode}_policy_table_rating"] = calculate_table_rating(quoting_params, mode, premiums[age][mode]["annual_policy_base"], modal_factor["#{mode}_factor"], @table_rating)
					premiums[age][mode]["#{mode}_policy_total"] += premiums[age][mode]["#{mode}_policy_table_rating"]
				end
				premiums[age][mode]["#{mode}_policy_total"] = premiums[age][mode]["#{mode}_policy_total"].round(2)
			end
		end
		return premiums
	end

	def set_riders_and_ratings(quoting_params)
		if quoting_params[:child_rider]
			@child_rider = RiderRate.find(self.child_rider_id) rescue nil
		end
		if quoting_params[:wop_rider]
			@wop_rider = RiderRate.find(self.wop_rider_id) rescue nil
		end
		if quoting_params[:adb_rider]
			@adb_rider = RiderRate.find(self.adb_rider_id) rescue nil
		end
		if quoting_params[:table_rating].present? && TableRate.find(self.table_rate_id)["table_#{quoting_params[:table_rating]}"]
			@table_rating = TableRate.find(self.table_rate_id)
		end
		if !quoting_params[:flat_extra].nil? && quoting_params[:flat_extra].to_i > 0
			@flat_extra = true
		else
			@flat_extra = false
		end

	end

	def calculate_child_rider(quoting_params, mode)
		child_rider_premium = @child_rider["age_#{quoting_params[:age]}"] * quoting_params[:child_rider_units] * @modal_factor["#{mode}_factor"]
	end

	def calculate_wop_rider(quoting_params, mode)
		wop_rider_premium = (@wop_rider["age_#{quoting_params[:age]}"] * (quoting_params[:face_amount]/1000)).round(2).to_f * @modal_factor["#{mode}_factor"]
	end

	def calculate_adb_rider(quoting_params, mode)
		adb_rider_premium = (@adb_rider["age_#{quoting_params[:age]}"] * (quoting_params[:face_amount]/1000)).round(2).to_f * @modal_factor["#{mode}_factor"]
	end

	def calculate_table_rating(quoting_params, mode, annual_policy_base, modal_factor, table_rating)
		table_rate_premium = ((annual_policy_base * (table_rating["table_#{quoting_params[:table_rating]}_percent"] / 100 )) * modal_factor).round(2).to_f * @modal_factor["#{mode}_factor"]
	end
end
