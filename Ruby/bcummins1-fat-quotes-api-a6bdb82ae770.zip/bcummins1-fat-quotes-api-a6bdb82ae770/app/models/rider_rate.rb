class RiderRate < ApplicationRecord
	belongs_to :data_version

	def update_base_rate_columns
		if rider_type == "child"
			@base_rate_columns = BaseRateColumn.where(:child_rider_id => id).all
			@base_rate_columns.update(:child_rider_id => nil)
			@base_rate_columns = BaseRateColumn.where(:data_version_id => data_version_id, :product_id => JSON.parse(product_ids), :health_category_id => JSON.parse(health_category_ids)).all
			@base_rate_columns.each do |base_rate_column|
				gender_match = gender == "Both" || base_rate_column.gender == gender
				tobacco_match = tobacco ==  "Both" || ((!base_rate_column.tobacco && tobacco  == "NonSmoker" ) || ((base_rate_column.tobacco ) && tobacco == "Tobacco"))
				if gender_match && tobacco_match
					base_rate_column.child_rider_id = id
					base_rate_column.save
				end
			end
		elsif rider_type == "wop"
			@base_rate_columns = BaseRateColumn.where(:wop_rider_id => id).all
			@base_rate_columns.update(:wop_rider_id => nil)
			@base_rate_columns = BaseRateColumn.where(:data_version_id => data_version_id, :product_id => JSON.parse(product_ids), :health_category_id => JSON.parse(health_category_ids)).all
			@base_rate_columns.each do |base_rate_column|
				gender_match = gender == "Both" || base_rate_column.gender == gender
				tobacco_match = tobacco ==  "Both" || ((!base_rate_column.tobacco && tobacco  == "NonSmoker" ) || ((base_rate_column.tobacco ) && tobacco == "Tobacco"))
				if gender_match && tobacco_match
					base_rate_column.wop_rider_id = id
					base_rate_column.save
				end
			end
		elsif rider_type == "adb" 
			@base_rate_columns = BaseRateColumn.where(:adb_rider_id => id).all
			@base_rate_columns.update(:abd_rider_id => nil)
			@base_rate_columns = BaseRateColumn.where(:data_version_id => data_version_id, :product_id => JSON.parse(product_ids), :health_category_id => JSON.parse(health_category_ids)).all
			@base_rate_columns.each do |base_rate_column|
				gender_match = gender == "Both" || base_rate_column.gender == gender
				tobacco_match = tobacco ==  "Both" || ((!base_rate_column.tobacco && tobacco  == "NonSmoker" ) || ((base_rate_column.tobacco ) && tobacco == "Tobacco"))
				if gender_match && tobacco_match
					base_rate_column.abd_rider_id = id
					base_rate_column.save
				end
			end
		else
			return
		end
	end

	def delete_rider_ids_from_base_rate_columns
		if rider_type == "child"
			@base_rate_columns = BaseRateColumn.where(:child_rider_id => id).all
			@base_rate_columns.update(:child_rider_id => nil)
		elsif rider_type == "wop"
			@base_rate_columns = BaseRateColumn.where(:wop_rider_id => id).all
			@base_rate_columns.update(:wop_rider_id => nil)
		elsif rider_type == "adb"
			@base_rate_columns = BaseRateColumn.where(:adb_rider_id => id).all
			@base_rate_columns.update(:abd_rider_id => nil)
		end
	end

end
