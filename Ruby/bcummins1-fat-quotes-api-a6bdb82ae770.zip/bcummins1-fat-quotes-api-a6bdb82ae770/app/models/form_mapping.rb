class FormMapping < ApplicationRecord
	belongs_to :form
end
