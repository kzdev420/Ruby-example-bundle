class Form < ApplicationRecord
	mount_uploader :file, ::FormUploader
	has_many :form_mappings
	has_many :sections

	def get_form_structure
		qs = {"sections" => []}
		self.sections.each_with_index do |section, sectionIndex|
			qs["sections"].push({:name => section.title, :questions => []})
			section.ordered_questions.each do |question|
				qs["sections"][sectionIndex][:questions].push({:question_id => question.id, :answer => "", :text => question.text, :options => question.options, :help_text => question.help_text, :question_type => question.question_type, :row => question.row, :column => question.column, :table_id => question.table_id})
			end
		end
		return qs.to_json
	end

end
