class Fip < ApplicationRecord
	has_one :form
	has_one :user
	mount_uploader :file, ::FipUploader
end
