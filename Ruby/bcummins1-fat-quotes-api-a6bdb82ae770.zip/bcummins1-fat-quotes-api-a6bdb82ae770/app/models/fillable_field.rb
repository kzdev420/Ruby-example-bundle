class FillableField < ApplicationRecord
	belongs_to :question, optional: true
end
