class Band < ApplicationRecord
	belongs_to :data_version
end
