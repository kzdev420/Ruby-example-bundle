class FillableFieldsController < ApplicationController
  before_action :set_carrier, :except => [:fillable_fields_engine]
  before_action :set_data_version, :except => [:fillable_fields_engine]
  before_action :set_form

  
  def index
    @fillable_fields = FillableField.where(:form_id => @form.id)
  end

  def new
    @fillable_field = FillableField.new
  end

  def create
    @fillable_fields = FillableField.new(fillable_fields_create_params.merge(:form_id => @form.id))
    if @fillable_fields.save
      flash[:notice] = "New fillable_fields created!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the fillable_fields"
      redirect_to :back
    end
  end

  def show
    @fillable_field = FillableField.find(params[:id])
  end

  def edit
    @fillable_field = FillableField.find(params[:id])
  end


  def destroy
    @fillable_field = FillableField.find(params[:id])
    if @fillable_field.destroy
      flash[:notice] = "Fillable Field destroyed!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error deleting the fillable form."
      redirect_to :back
    end
    
  end

  def update
    @fillable_fields = FillableField.find(params[:id])

    if @fillable_fields.update(fillable_fields_create_params)
      flash[:notice] = "Fillable Field updated!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error saving the carrier"
      redirect_to :back
    end
  end

  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_form
    @form = Form.find(params[:form_id]) rescue nil
    if !@form
      @errors[:id] = "You are missing the form record number"
    end
  end

  def fillable_fields_create_params
    params.require(:fillable_field).permit(:name, :name_alt, :field_type, :options, :flags, :justification, :question_id)
  end

end