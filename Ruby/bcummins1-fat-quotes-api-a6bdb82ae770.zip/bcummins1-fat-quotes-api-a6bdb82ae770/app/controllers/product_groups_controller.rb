class ProductGroupsController < ApplicationController
	before_action :set_carrier

	def index
		@product_groups = ProductGroup.where(:carrier_id => @carrier.id).all
	end

	def new
		@product_group = ProductGroup.new
	end

  def edit
    @product_group = ::ProductGroup.find(params[:id])
  end

	def create
		@product_group = @carrier.product_groups.new(product_group_params)
    @product_group.carrier_id = @carrier.id
    if @product_group.save
      @product_group.update(:state_approval => StateApproval.new(:product_group_id => @product_group.id))
      @product_group.save
      @product_group.state_approval.reset_state_approval(params[:state_approval])
      flash[:notice] = "Product group created!"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error"
      redirect_to :back
    end
	end

	def destroy
		@product_group = ::ProductGroup.find(params[:id])
    if @product_group.destroy
      flash[:notice] = "Product Group deleted"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error"
      redirect_to :back
    end
	end

	def update
    @product_group = ::ProductGroup.find(params[:id])
    @state_approval = @product_group.state_approval
    @states_approved = params[:state_approval] || []
    if @product_group.update(product_group_params)
      @state_approval.reset_state_approval(@states_approved)
      flash[:notice] = "Successfully updated"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error"
      redirect_to :back
    end
  end

	def show
		@product_group = ProductGroup.find(params[:id])
	end

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You must select a carrier."
		end
	end

	def product_group_params
    params.require(:product_group).permit(:group_name)
  end

end
