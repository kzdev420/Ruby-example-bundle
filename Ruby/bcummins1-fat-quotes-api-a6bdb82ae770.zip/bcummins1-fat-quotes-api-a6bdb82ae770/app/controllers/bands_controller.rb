class BandsController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version
	
	def index
		@bands = Band.where(:data_version_id => @data_version.id).order('band_name')
		@base_url = "/carriers/#{@carrier.id}/data_versions/#{@data_version.id}/bands"
		@modal_factors = ModalFactor.where(:data_version_id => @data_version.id)
	end

	def new
		@band = Band.new
	end

	def create
		@band_data = JSON.parse(params.to_json)
		annual_policy_fee = @band_data["policy_fees"]["policy_fee_annual"]
		@modal_factor = ModalFactor.find(@band_data["modal_factor_id"])
		policy_fees = {"policy_fee_annual" => annual_policy_fee, "policy_fee_semi_annual" => annual_policy_fee * @modal_factor.semi_annual_factor , "policy_fee_quarterly" => annual_policy_fee * @modal_factor.quarterly_factor, "policy_fee_monthly" => annual_policy_fee * @modal_factor.monthly_factor}
		@band_data["bands"].each do |band|
			@band = Band.create(band.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id).merge(@band_data["bandCalcSettings"]).merge(policy_fees))
		end
		respond_to do |format|
			format.json { render json:  "Success!" }
    end
	end

	def show
		@band = Band.find(params[:id])
	end

	def update
		@band = Band.find(params[:id])

    if @band.update(band_params)
      flash[:notice] = "Band successfully saved!"
      redirect_to carrier_data_version_bands_path(@carrier, @data_version)
    else
      render :action => "edit"
    end
	end

	def destroy
    @band = Band.find(params[:id])
    @band.destroy
    flash[:notice] = "Band deleted"
    redirect_to :back
  end

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def band_params
    params.require(:band).permit(:band_name, :face_amount_start, :face_amount_end, :min_premium_annual, :max_premium_annual, :min_premium_semi_annual, 
                                 :max_premium_semi_annual, :min_premium_quarterly, :max_premium_quarterly, :min_premium_monthly, :max_premium_monthly, 
                                 :age_start, :age_end, :round_base_rate_before_modal, :round_base_rate_after_modal, :multiply_policy_fee_by_modal, 
                                 :round_policy_fee_before_addition, :policy_fee_annual, :policy_fee_semi_annual, :policy_fee_quarterly, :policy_fee_monthly, 
                                 :round_flat_extra_before_modal, :round_flat_extra_after_modal, :age_calculation_type, :policy_fee_commissionable)
  end

  def batch_band_params
  	params.permit(:bandCalcSettings => {}, :policy_fees => {})
  end

end
