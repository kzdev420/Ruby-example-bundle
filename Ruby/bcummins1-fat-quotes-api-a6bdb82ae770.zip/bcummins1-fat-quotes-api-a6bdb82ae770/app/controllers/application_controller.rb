class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  before_action :configure_permitted_parameters, if: :devise_controller?
  before_action :allow_cross_domain_ajax
  layout :layout


  def allow_cross_domain_ajax
      headers['Access-Control-Allow-Origin'] = 'http://localhost:3001'
      headers['Access-Control-Request-Method'] = 'POST, OPTIONS, GET'

  end

  private

  def layout
    # only turn it off for login pages:
    #Here is where we can generate the layouts that we are looking for. 
    is_a?(Devise::SessionsController) ? false : "application"
  end

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:name])
    devise_parameter_sanitizer.permit(:account_update, keys: [:name])
  end

end
