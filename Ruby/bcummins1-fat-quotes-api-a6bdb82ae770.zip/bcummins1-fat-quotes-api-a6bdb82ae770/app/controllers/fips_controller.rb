class FipsController < ApplicationController
  before_action :set_form

  
  def index
    @fip = Fip.where(:user_id => @user.id)
  end


  def update
    @fip = Fip.find(params[:id])
    @form = @fip.form
    if @fip.update(fip_create_params)
      flash[:notice] = "Fip updated!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form"
      redirect_to :back
    end
  end

  def create
    @form = Form.find(params[:form_id])
    @fip = Fip.new(fip_create_params.merge(:form_id => params[:form_id]))
    if @fip.save
      flash[:notice] = "Fip created!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form"
      redirect_to :back
    end
  end

  def destroy
    @fip = Fip.find(params[:id])
    if @fip.destroy
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    end
  end

  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_form
    @form = Form.find(params[:form_id]) rescue nil
    if !@form
      @errors[:id] = "You are missing the form record number"
    end
  end

  def fip_create_params
    params.require(:fip).permit(:responses, :user_id, :form_structure)
  end

end