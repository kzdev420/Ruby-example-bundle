class QuestionsController < ApplicationController
  before_action :set_carrier
  before_action :set_data_version
  
  def index
    @section = Section.find(params[:section_id])
    @questions = Question.where(:section_id => @section.id).order(:order)
    @form = @section.form
  end

  def new
    @question = Question.new
    @section = Section.find(params[:section_id])
    @form = @section.form
  end

  def show
    
  end

  def create
    @question = Question.new(question_create_params.merge(:section_id => params[:section_id]))
    @section = @question.section
    @form = @section.form
    if @question.save
      flash[:notice] = "Question successfully saved!"
      redirect_to carrier_data_version_form_section_questions_path(@carrier, @data_version, @form, @section)
    else
      flash[:notice] = "There was an error creating this health_category"
      redirect_to :back
    end

  end

  def edit
    @question = Question.find(params[:id])
    @section = @question.section 
    @form = @section.form
  end

  def update
    @question = Question.find(params[:id])
    @section = @question.section
    @form = @section.form
    if @question.update(question_create_params)
      flash[:notice] = "Question successfully updated!"
      if params[:commit] == "Save"
        redirect_to carrier_data_version_form_section_questions_path(@carrier, @data_version, @form, @section)
      else
        @questions = @section.questions.order(:created_at)
        @next_question = @questions[@questions.index{|x|x.id==@question.id} + 1]
        redirect_to edit_carrier_data_version_form_section_question_path(@carrier, @data_version, @form, @section, @next_question)
      end

    else
      flash[:notice] = "There was an error creating this health_category"
      redirect_to :back
    end
  end

  def destroy
    @question = Question.find(params[:id])
    @section = @question.section
    @form = @section.form
    if @question.destroy
      flash[:notice] = "Question successfully deleted!"
      redirect_to carrier_data_version_form_section_questions_path(@carrier, @data_version, @form, @section)
    else
      flash[:notice] = "There was an error deleting the carrier"
      redirect_to :back
    end
  end

  

  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def question_create_params
    params.require(:question).permit(:text, :help_text, :question_type, :order, :row, :column, :table_id)
  end

end