class FormMappingsController < ApplicationController
  before_action :set_carrier
  before_action :set_data_version
  before_action :set_form
  
  def new
    @form_mapping = FormMapping.new 
    @product_groups = ProductGroup.where(:carrier_id => @carrier.id) 
  end

  def create
    @form_mapping = FormMapping.new(form_mappings_create_params.merge(:carrier_id => params[:carrier_id], :data_version_id => params[:data_version_id], :form_id => params[:form_id]))
    if @form_mapping.save
      flash[:notice] = "New form mapping created!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form mapping."
      redirect_to :back
    end
    
  end

  def edit
    @form_mapping = FormMapping.find(params[:id])
    @product_groups = ProductGroup.where(:carrier_id => @carrier.id)
  end

  def update
    @form_mapping = FormMapping.find(params[:id])

    product_groups = params[:form_mapping][:product_groups]

    product_groups.each do |pg|
      @form_mapping.update(form_mappings_create_params.merge(:product_group_id => pg))
    end

    if @form_mapping.update(form_mappings_create_params)
      flash[:notice] = "Form mapping updated!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error saving the carrier"
      redirect_to :back
    end
  end

  def destroy
    @form_mapping = FormMapping.find(params[:id])
    if @form_mapping.destroy
      flash[:notice] = "Form mapping was successfully destroyed"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    end
  end


  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_form
    @form = Form.find(params[:form_id]) rescue nil
    if !@form
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def form_mappings_create_params
    params.require(:form_mapping).permit(:new_business, :policyholder_service, :marketing, :contracting, :state_AL,:state_AK,:state_AS,:state_AZ,:state_AR,
                                 :state_CA,:state_CO,:state_CT,:state_DE,:state_DC,:state_FM,:state_FL,:state_GA,:state_GU,:state_HI,:state_ID,:state_IL,
                                 :state_IN,:state_IA,:state_KS,:state_KY,:state_LA,:state_ME,:state_MH,:state_MD,:state_MA,:state_MI,:state_MN,:state_MS,
                                 :state_MO,:state_MT,:state_NE,:state_NV,:state_NH,:state_NJ,:state_NM,:state_NY,:state_NC,:state_ND,:state_MP,:state_OH,
                                 :state_OK,:state_OR,:state_PW,:state_PA,:state_PR,:state_RI,:state_SC,:state_SD,:state_TN,:state_TX,:state_UT,:state_VT,
                                 :state_VI,:state_VA,:state_WA,:state_WV,:state_WI,:state_WY)
  end

end