class CarriersController < ApplicationController
	before_filter :get_carrier, :except => [:index, :new, :create]
	before_action :authenticate_user!

	def index
		@carriers = Carrier.all.order(:name)
	end

  def new
    @carrier = Carrier.new
  end

  def create
    @carrier = Carrier.new(carrier_create_params)
    if @carrier.save
      flash[:notice] = "New carrier created!"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error creating the carrier"
      redirect_to :back
    end
  end

  def show
    @carrier = Carrier.find(params[:id])
    @product_groups = ProductGroup.where(:carrier_id => @carrier.id)
    @products = Product.where(:carrier_id => @carrier.id)
    @quote_versions = DataVersion.where(:carrier_id => @carrier.id, :data_type => "quotes")
    @form_versions = DataVersion.where(:carrier_id => @carrier.id, :data_type => "forms")
  end

  def update
    if @carrier.update(carrier_create_params)
      flash[:notice] = "Carrier updated!"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error saving the carrier"
      redirect_to :back
    end
  end

  def destroy
    @carrier = Carrier.find(params[:id])
    if @carrier.destroy
      flash[:notice] = "Carrier destroyed!"
      redirect_to carriers_path
    end
  end

  def test
    
  end

	
private 

  def carrier_create_params
    params.require(:carrier).permit(:name, :external_code, :street1, :street2, :city, :state, :zipcode, :phone, :email, :website, :logo)
  end

	def get_carrier
		@errors = {}
		@carrier = Carrier.find(params[:id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

end