class BuildChartsController < ApplicationController
  before_action :get_carrier, :except => [:get_build_charts]

  # GET /build_charts
  # GET /build_charts.json
  def index
    @subMenuButtonSelected = "health_categories"
    @build_charts = BuildChart.where(:carrier_id => @carrier.id)
  end

  # GET /build_charts/1
  # GET /build_charts/1.json
  def show
  end

  # GET /build_charts/new
  def new
    @build_chart = BuildChart.new
  end

  def edit
    @build_chart = ::BuildChart.find(params[:id])
  end

  def create
    @build_chart = BuildChart.new(build_chart_params.merge(:carrier_id => @carrier.id))
    if @build_chart.save
      flash[:notice] = "Build Chart successfully saved!"
      redirect_to carrier_build_charts_path(@carrier)
    else
      flash[:notice] = "There was an error creating this build_chart"
      redirect_to :back
    end
  end

  def update
    @build_chart = BuildChart.find(params[:id])
    if @build_chart.update(build_chart_params)
      flash[:notice] = "BuildChart successfully saved!"
      redirect_to carrier_build_charts_path(@carrier)
    else
      flash[:notice] = "There was an error updating this build_chart"
      redirect_to :back
    end
  end

  def get_build_charts
    @carrier = Carrier.where(:name => params[:company]).first
    @version = DataVersion.where(:carrier_id => @carrier.id).last
    @inform_health_caategory = params[:health_category_type]
    @carrier_health_category = params[:health_category]
    @health_category = HealthCategory.where(:carrier => @carrier.id, :data_version_id => @version.id, :carrier_health_category => @carrier_health_category, :fat_quote_health_category => @health_category_type)
    if @health_category
      render json: {"build_chart" => @health_category.build_chart}
    end
  end

  def destroy
    @build_chart = BuildChart.find(params[:id])
    @build_chart.destroy
    flash[:notice] = "Health category deleted"
    redirect_to :back
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_build_chart
      @build_chart = BuildChart.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def build_chart_params
      params.require(:build_chart).permit(::BuildChart.column_names)
    end

    def get_carrier
      @errors = {}
      @carrier = Carrier.find(params[:carrier_id]) rescue nil
      if !@carrier
        @errors[:carrier_id] = "You are missing the carrier record number"
      end
    end
    
end
