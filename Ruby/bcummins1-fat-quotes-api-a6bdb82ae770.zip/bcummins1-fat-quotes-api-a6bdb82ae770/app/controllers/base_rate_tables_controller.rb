class BaseRateTablesController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version

	RIDER_MAP = {
    "adb" => {:name => "Accidental Death Benefit"},
    "wop" => {:name => "Waiver of Premium"},
    "child" => {:name => "Child"},
    "child_wop" => {:name => "Child/Waiver of Premium Combined"}
  }

	def index
		@base_rate_tables = BaseRateTable.where(:data_version_id => @data_version.id).all
		@product_groups = ProductGroup.where(:carrier_id => @carrier.id).all
		@modal_factors = ModalFactor.where(:data_version_id => @data_version.id)
		@bands = Band.where(:data_version_id => @data_version.id)
		@base_url = "/carriers/#{@carrier.id}/data_versions/#{@data_version.id}/base_rate_tables"
	end

	def show
		@base_rate_tables = BaseRateTable.where(:data_version_id => @data_version.id).order("id")
		@products = Product.where(:carrier_id => @carrier.id).all
		@modal_factors = ModalFactor.where(:data_version_id => @data_version.id).all
		@bands = Band.where(:data_version_id => @data_version.id).all
		@base_rate_table = BaseRateTable.find(params[:id])
		@brt_index = @base_rate_tables.find_index(@base_rate_table)
		@next_base_rate_table = @brt_index == @base_rate_tables.count - 1 ? @base_rate_tables[0] : @base_rate_tables[@brt_index + 1]
		@product = Product.find(@base_rate_table.product_id)
		@modal_factor = ModalFactor.find(@base_rate_table.modal_factor_id)
		@band = Band.find(@base_rate_table.band_id)
		@base_rate_columns = BaseRateColumn.where(:base_rate_table_id => @base_rate_table.id).all
	end

	def create
		@base_rate_table =  BaseRateTable.new(base_rate_table_params.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id))
		if @base_rate_table.save
			flash[:notice] = "Successfully created the quote table"
			redirect_to carrier_data_version_base_rate_tables_path(@carrier, @data_version)
		else
			flash[:notice] = "There was an error creating the base rate table"
      redirect_to :back
		end
	end

	def update
		@base_rate_table = BaseRateTable.find(params[:id]) 
		if @base_rate_table.update(base_rate_table_params)
			@base_rate_table.update_base_rate_columns
	      flash[:notice] = "Successfully updated the quote table"
	      redirect_to carrier_data_version_base_rate_tables_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error saving the quote table"
      redirect_to :back
    end
	end

	def edit
		@base_rate_table = BaseRateTable.find(params[:id])
		@products = Product.where(:carrier_id => @carrier.id).all
		@modal_factors = ModalFactor.where(:data_version_id => @data_version.id).all
		@bands = Band.where(:data_version_id => @data_version.id).all
	end

	def destroy
		@base_rate_table = BaseRateTable.find(params[:id])
		if @base_rate_table.destroy
	      flash[:notice] = "Successfully deleted the quote table"
	      redirect_to carrier_data_version_base_rate_tables_path(@carrier, @data_version)
	  else
	      flash[:notice] = "There was an error deleted the quote table"
	      redirect_to :back
	  end
	end

	def get_spreadsheet_layout_data (product_group_ids, params)
		@product_groups = ProductGroup.where(:id => product_group_ids).pluck(:group_name).map{ |pg| {pg => {"products" => [], "health_categories" => [], "bands" => []}}}
		@product_groups.each do |pg|
			pg.each do |k, v|
				@product_group = ProductGroup.where(:carrier_id => @carrier.id, :group_name => k).first
				v["products"] = Product.where(:carrier => @carrier.id, :product_group_id => @product_group.id).pluck(:product_name)
				v["health_categories"] = HealthCategory.where(:data_version_id => params[:data_version_id]).order(:tobacco_category_type).pluck(:carrier_health_category)
				if params[:bands].present?
					v["bands"] = Band.where(:id => params[:bands][@product_group.id.to_s]).order(:face_amount_start).pluck(:band_name)
				else 
					base_rate_tables = BaseRateTable.where(:data_version_id => @data_version.id, :product_id => @product_group.products.ids)
					band_ids = base_rate_tables.pluck(:band_id)
					v["bands"] = Band.where(:id => band_ids).order(:face_amount_start).pluck(:band_name)
				end
				
				v["genders"] = ["Male","Female"]
				v["modal_factor"] = params["modalFactors"].nil? ? ModalFactor.where(:data_version_id => @data_version.id).first.name : ModalFactor.find(params["modalFactors"][@product_group.id.to_s]).name 
			end
		end
		column_headers = get_column_data(@product_groups, params[:write_results])
		return column_headers
  end

  def upload_excel
  	file_information = params[:data_version]["rate_file"].original_filename.split("_")
  	error = verify_file(file_information)
  	if error.present?
  		flash[:warning] = error
	    redirect_to :back
  	end
    xlsx = Roo::Spreadsheet.open(params[:data_version]["rate_file"].tempfile)
    xlsx.each_with_pagename do |sheet_name, sheet|
    	product_group_id = ProductGroup.where(:carrier_id => @carrier.id, :group_name => sheet.row(2)[0]).first.id
    	modal_factor_id = ModalFactor.where(:data_version_id => @data_version.id, :name => sheet.row(3)[0]).first.id
    	base_rate_tables = assign_columns_to_tables(sheet)
    	create_base_rate_tables(base_rate_tables, modal_factor_id, product_group_id)
    end
    flash[:notice] = "Excel upload was successful."
	  redirect_to :back
    
  end

  def generate_excel
  	@product_group_ids = ProductGroup.where(:id => params[:product_groups].keys).pluck(:id)
  	@layout_data = get_spreadsheet_layout_data(@product_group_ids, params)
  	file_name = "#{@carrier.name}_#{params[:data_version_id]}_#{SecureRandom.uuid}.xlsx"
  	workbook = initialize_spreadsheet(file_name)
  	write_spreadsheet_layout(workbook, @layout_data, params[:riders])
  	workbook.close
  	send_file file_name
  end




	private

	def verify_file(file_information)
		if !file_information[2].include?("xlsx" || "xls")
  		return "Unaccepted file type. Please upload one of the following file types: .xlsx, .xls, .odt"
  	end
  	if DataVersion.find(file_information[1]).nil? 
  		return "This spreadsheet does not correspond to the current data version. Please download a template spreadsheet and try again."
  	end
  	if DataVersion.find(file_information[1]).carrier_id != @carrier.id
  		return "This spreadsheet does not correspond to the current carrier. Import Failed."
  	end
  	return nil
	end

	def create_base_rate_tables(base_rate_tables, modal_factor_id, product_group_id)
		base_rate_tables.each do |product, bands|
			@product = Product.where(:carrier_id => @carrier.id, :product_name => product, :product_group_id => product_group_id).first
			bands.each do |band, parts|
				@band = Band.where(:data_version_id => @data_version.id, :band_name => band.split('-')[0]).first
				@brt = BaseRateTable.find_or_create_by(:carrier_id => @carrier.id, :modal_factor_id => modal_factor_id, :data_version_id => @data_version.id, :product_id => @product.id, :band_id => @band.id)
				@modal_factor_id = modal_factor_id
				@product_group_id = product_group_id
				parts.each do |part, columns|
					columns.each do |column|
						next if column[4..100].all? {|a| a.nil? }
						@hc = HealthCategory.where(:data_version_id => @data_version.id, :carrier_health_category => column[3]).first
						@tobacco = @hc.tobacco_category_type == "Tobacco"
						@brc = @brt.base_rate_columns.find_or_create_by(:data_version_id => @data_version.id, :carrier_id => @carrier.id, :product_id => @product.id, :modal_factor_id => @modal_factor_id, :band_id => @band.id, :gender => column[2], :health_category_id => @hc.id, :tobacco => @tobacco, :col_type => "Normal")
						if part == "Base Rates"
							add_or_modify_base_rate_column(column, modal_factor_id, product_group_id) 
						else
							part_synthesis = {"Child" => "child", "Waiver of Premium" => "wop", "Accidental Death Benefit" => "adb"}
							add_or_modify_rider_column(column, part_synthesis[part])
						end
						
					end
				end
			end
		end
	end

	def add_or_modify_base_rate_column(column, modal_factor_id, product_group_id)
		(0..103).each do |age|
			next if column[age + 4].nil?
			@brc["age_#{age}"] = column[age + 4]
		end
		@brc.save
	end

	def add_or_modify_rider_column(column, rider_type)
		comparable = get_rider_data_object(column)
		comparable["rider_type"] = rider_type
		@rider = RiderRate.find_or_create_by(comparable)
		if @rider.name.nil?
			@rider.update(:name => "#{rider_type}-#{column[0]}-#{column[1]}")
			
		end
		@brc.update("#{rider_type}_rider_id" => @rider.id)
	end

	def get_rider_data_object(column)
		comparable = {:data_version_id => @data_version.id, :carrier_id => @carrier.id}
		column[4..100].each_with_index{|k,v| comparable["age_" + v.to_s] = k.nil? ? 0 : k.to_d}
		return comparable
	end

	def assign_columns_to_tables(sheet)
    base_rate_tables = {}
    importable_parts = get_importable_parts(sheet.column(1))
    sheet.first_column.upto(sheet.last_column) do |c_index|
    	column = sheet.column(c_index)
    	next if c_index == 1 || column[0..3].include?(nil)
    	base_rate_tables[column[0]] ||= {}
    	base_rate_tables[column[0]][column[1]] ||= {}
    	importable_parts.each do |part, part_data|
    		base_rate_tables[column[0]][column[1]][part] ||= []
    		base_rate_tables[column[0]][column[1]][part] << column[part_data["start_row"] - 3 ..part_data["start_row"] + 100]
    	end
    end 
    return base_rate_tables  
  end

  def get_importable_parts(column)
  	importable_parts = {}
  	["Base Rates", "Waiver of Premium", "Child", "Accidental Death Benefit"].each do |part|
  		next if column.index(part).nil?
			importable_parts[part] = {"start_row" => column.index(part) }
		end
		return importable_parts
  end


  def initialize_spreadsheet(file_name)
  	workbook = WriteXLSX.new(file_name)
  	#pink
    workbook.set_custom_color(14, 244, 194, 194) 
    #blue
    workbook.set_custom_color(15, 137, 207, 240) 
    return workbook
  end

  

  def write_spreadsheet_layout(workbook, pages, riders)
  	@maleFormat = {
        :bg_color => 15,
        :bold  => 1,
        :color => 'white',
        :align => 'center',

	  }
	  @femaleFormat = {
	      :bg_color => 14,
	      :bold  => 1,
	      :color => 'white',
	      :align => 'center'
	  }
    pages.each do |page_name, columns|
    	addable_riders = riders.nil? ? {} : riders[ProductGroup.where(:group_name => columns[0][1]).first.id.to_s].keys
    	age_range= {"start_age" => 0, "end_age" => 100}
    	worksheet = workbook.add_worksheet(page_name.truncate(30))
    	worksheet.set_column(1, 800, 40 + addable_riders.size * 10)
    	start_location = {"row" => 0, "column" => 0}
    	write_spreadsheet_section(columns, age_range, "Base Rates", nil, workbook, worksheet, start_location)
    	["Waiver of Premium", "Child", "Accidental Death Benefit"].each do |rider|
    		next unless addable_riders.include?(rider)
    		start_location["row"] += 106
    		write_spreadsheet_section(columns, age_range, rider , nil, workbook, worksheet, start_location)
    	end

    end
  end

  def write_spreadsheet_section(columns, age_range, section_title, key, workbook, worksheet, start_location)
  	row_offset = start_location["row"]
  	column_offset = start_location["column"]
  	columns[0][3] = section_title
  	
  	#Write the side of the section
  	age_range["start_age"].upto(age_range["end_age"]).each_with_index do |age, i|
  		columns[0][5 + i] = age
  	end

  	#Write the columns
  	columns.each_with_index do |column, i|
			columnFormat = column[2] == "Male" ? @maleFormat : @femaleFormat
			if column[4]
		    columnFormat[:right] = 1
		  else
		    columnFormat[:right] = 0
		  end
		  q = workbook.add_format(columnFormat)
		  worksheet.write(row_offset, i, column[0], q)
		  worksheet.write(row_offset + 1, i, column[1], q)
		  worksheet.write(row_offset + 2, i, column[2], q)
		  worksheet.write(row_offset + 3, i, column[3], q)
		  wrap = workbook.add_format()
		  wrap.set_text_wrap()
		  4.upto(104).each do |q|
		  	worksheet.write(q, i, column[q + 1], wrap)
		  end
		end

  end

  def get_column_data (product_groups, print_premiums)
    column_headers = {}
    product_groups.each do |pg|
    	pg.each do |group_name, group_information|
    		product_group = ProductGroup.where(:group_name => group_name, :carrier_id => @carrier.id).first
    		riders = params[:riders].nil? ? {} : params[:riders][ProductGroup.where(:group_name => group_name).first.id.to_s].keys
	    	column_headers[group_name] ||= []
	    	column_headers[group_name] << [@carrier.name, group_name, group_information["modal_factor"], nil, nil]
	    	group_information["products"].each do |pn|
	    		product = Product.where(:product_name => pn, :product_group_id => product_group.id).first
		      group_information["bands"].each do |b|
		      	band = Band.where(:data_version_id => @data_version.id, :band_name => b.split('-')[0]).first
		        group_information["genders"].each do |g|
		          group_information["health_categories"].each_with_index do |hcn, hcnIndex|
		          	health_category = HealthCategory.where(:data_version => @data_version.id, :carrier_health_category => hcn ).first
		            outline = hcnIndex == group_information["health_categories"].size - 1
		            column = [pn, b + "-#{ ActionController::Base.helpers.number_to_currency(band.face_amount_start)}", g, hcn, outline]
		            if print_premiums == "true"
		            	@base_rate_column = BaseRateColumn.where(:health_category_id => health_category.id, :data_version_id => @data_version.id, :band_id => band.id, :product_id => product.id, :gender => g).first
		            	next if @base_rate_column.nil?
		            	premiums = @base_rate_column.get_column_premiums(riders)
		            	premiums.each do |age, premium_results|
		            		if premiums[age].empty?
		            			column << nil
		            			next
		            		end
		            		result = ""
		            		premium_results.each do |mode, mode_results|
		            			mode_policy_base = mode_results["#{mode}_policy_base"]
		            			mode_policy_fee = mode_results["#{mode}_policy_fee"]
		            			mode_policy_total = mode_results["#{mode}_policy_total"]
		            			rider_fees = get_rider_fees(mode_results, mode)
		            			result += "#{mode}: B: $#{mode_policy_base} / F: $#{mode_policy_fee} / #{rider_fees} / T: $#{mode_policy_total}\n"
		            		end
		            		column << result
		            	end

		            end
		            column_headers[group_name] << column
		          end
		        end
		      end
		    end
		  end
    end
    return column_headers
  end

  def get_rider_fees(mode_results, mode)
  	riders = ""
  	["child", "wop", "adb"].each do |rider|
  		next unless mode_results["#{mode}_policy_#{rider}_rider"]
  		riders += "#{rider}: #{mode_results["#{mode}_policy_#{rider}_rider"]} / "
  	end
  	return riders
  end

	def base_rate_table_params
    params.require(:base_rate_table).permit(:product_id, :notes, :band_id, :modal_factor_id)
  end

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

end
