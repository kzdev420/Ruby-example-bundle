class RiderRatesController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version

	def index
		@child_rider_rates = RiderRate.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id, :rider_type => "child").all
		@wop_rider_rates = RiderRate.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id, :rider_type => "wop").all
		@adb_rider_rates = RiderRate.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id, :rider_type => "adb").all


	end

	def new
		@rider_rate = RiderRate.new
		set_rider_variables
	end

	def show
		@rider_rate = ::RiderRate.find(params[:id])
		set_rider_variables
	end

	def create
		@rider_rate = ::RiderRate.new(rider_rate_params.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id))
  	@rider_rate.update_bands_products_health(params)
  	if @rider_rate.save
  		@rider_rate.update_base_rate_columns
    	flash[:notice] = "RiderRate successfully saved!"
    	redirect_to carrier_data_version_rider_rates_path(@carrier, @data_version)
  	else
    	set_rider_variables
    	render :action => :new
    end
	end

	def update
		@rider_rate = ::RiderRate.find(params[:id])
		@rider_rate.update_bands_products_health(params)
    if @rider_rate.update(rider_rate_params)
    	@rider_rate.update_base_rate_columns
      flash[:notice] = "RiderRate successfully saved!"
      redirect_to carrier_data_version_rider_rates_path(@carrier, @data_version)
    else
      set_rider_variables
      render :action => :new
    end
	end

	def destroy
		@rider_rate = ::RiderRate.find(params[:id])
		@rider_rate.delete_rider_ids_from_base_rate_columns
    @rider_rate.destroy
    flash[:notice] = "Rider deleted"
    redirect_to :back
	end

	private

	def rider_rate_params
		params.require(:rider_rate).permit(:rider_type, :name, :all_bands, :all_products, :all_health_categories, :gender, :tobacco, :modal_factor_id, :round_after_modal, 
                                            :lowest_table_rate, :max_flat_extra, :face_amount_start, :face_amount_end, :age_start, :age_end, :age_0, :age_1, :age_2, :age_3, :age_4, :age_5, :age_6, :age_7, :age_8, :age_9, 
                                            :age_10, :age_11, :age_12, :age_13, :age_14, :age_15, :age_16, :age_17, :age_18, :age_19, :age_20, :age_21, :age_22, :age_23, 
                                            :age_24, :age_25, :age_26, :age_27, :age_28, :age_29, :age_30, :age_31, :age_32, :age_33, :age_34, :age_35, :age_36, :age_37, 
                                            :age_38, :age_39, :age_40, :age_41, :age_42, :age_43, :age_44, :age_45, :age_46, :age_47, :age_48, :age_49, :age_50, :age_51, 
                                            :age_52, :age_53, :age_54, :age_55, :age_56, :age_57, :age_58, :age_59, :age_60, :age_61, :age_62, :age_63, :age_64, :age_65, 
                                            :age_66, :age_67, :age_68, :age_69, :age_70, :age_71, :age_72, :age_73, :age_74, :age_75, :age_76, :age_77, :age_78, :age_79, 
                                            :age_80, :age_81, :age_82, :age_83, :age_84, :age_85, :age_86, :age_87, :age_88, :age_89, :age_90, :age_91, :age_92, :age_93, 
                                            :age_94, :age_95, :age_96, :age_97, :age_98, :age_99, :age_100, :age_101, :age_102, :age_103, :age_104, :age_105, :age_106, 
                                            :age_107, :age_108, :age_109, :age_110, :age_111, :age_112, :age_113, :age_114, :age_115, :age_116, :age_117, :age_118, 
                                            :age_119, :age_120, :age_121, :age_122, :age_123, :age_124, :age_125, :age_126, :age_127, :age_128, :age_129, :age_130, 
                                            :age_131, :age_132, :age_133, :age_134, :age_135, :age_136, :age_137, :age_138, :age_139, :age_140)
	end

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_rider_variables
    @selected_bands = @rider_rate.band_ids || []
    @selected_products = @rider_rate.product_ids || []
    @selected_health_categories = @rider_rate.health_category_ids || []
    @bands = ::Band.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id).all
    @products = ::Product.where(:carrier_id => @carrier.id, :line_of_coverage => "Life").all
    @health_categories = ::HealthCategory.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id).all
    @modal_factors = ::ModalFactor.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id).all
  end
end
