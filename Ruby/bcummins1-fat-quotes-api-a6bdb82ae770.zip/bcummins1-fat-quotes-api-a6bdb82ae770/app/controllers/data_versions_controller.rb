require 'write_xlsx'

class DataVersionsController < ApplicationController
	before_action :set_carrier, except: [:quote_versions_carriers, :form_versions_carriers] 
	skip_before_action :verify_authenticity_token

	def index
		@version_type = params[:version_type]
		@data_versions = DataVersion.where(:carrier_id => @carrier.id, :data_type => @version_type).order('id ASC')
	end

	def new
		@data_version = DataVersion.create(:carrier_id => @carrier.id, :token => SecureRandom.hex(4), :data_type => params[:version_type])
		redirect_to carrier_path(@carrier)
	end

	def show
		@data_version = DataVersion.find(params[:id])
	end

	def form_dump
		@form_mappings = JSON.parse(request.body.read)
		@carrier = ProductGroup.find(@form_mappings[@form_mappings.keys[0]][0]["product_group_id"]).carrier
		@data_version = DataVersion.where(:carrier_id => @carrier.id, :data_type => "forms").order("created_at DESC")[0]
		@form_mappings.each do |form_name, form_mappings_array|
			form_mappings_array.each do |fm|
				form_name = fm["form_name"]
	      form_number = fm["form_number"]
	      form_description = fm["form_description"]
	      form_type = fm["form_product_group"]
	      form_mapping = fm["form_mapping"]
	      form_state = fm["form_state"]
	      form_path = fm["form_path"]
	      form_product_group_id = fm["product_group_id"]
	      @form = Form.where(:form_name => form_name, :form_number => form_number, :data_version_id => @data_version.id).first        
	      if @form
	        @form_mapping = @form.form_mappings.where(:product_group_id => form_product_group_id).first
	        if @form_mapping
	          @form_mapping.update("state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true) 
	        else
	          new_form_mapping = FormMapping.create(:form_id => @form.id, :product_group_id => form_product_group_id, :data_version_id => @data_version.id, "state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true)
	        end
	      else
	        @form = Form.create(:carrier_id => @carrier.id, :data_version_id => @data_version.id, :form_name => form_name, :form_number => form_number, :description => form_description)
	        new_form_mapping = FormMapping.create(:form_id => @form.id, :product_group_id => form_product_group_id, :data_version_id => @data_version.id, "state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true)
	      end
			end
		end
		render :json => {"message" => "Success"}, :status => 200
	end

	def destroy
		@data_version = DataVersion.find(params[:id])
		if @data_version.destroy
			flash[:notice] = "Data Version successfully deleted."
		else
			flash[:notice] = "Data Version was not deleted"
		end
		redirect_to carrier_path(@carrier)
	end

	def toggle_active_status
		@data_version = DataVersion.find(params[:data_version_id])
		if DataVersion.where(:carrier_id => @carrier.id, :live => true, :data_type => @data_version.data_type).where.not(:id => @data_version.id).exists?
			flash[:notice] = "There is a live version already. Please bring that version down first."
			redirect_to carrier_data_versions_path(@carrier, :version_type => @data_version.data_type)
			return
		end
		@data_version.update(:live => !@data_version.live)
		if @data_version.data_type == "quotes"
			Carrier.find(@data_version.carrier_id).update(:quotes_live => @data_version.live)
		else
			Carrier.find(@data_version.carrier_id).update(:forms_live => @data_version.live)
		end
		
		redirect_to carrier_data_versions_path(@carrier, :version_type => @data_version.data_type)
	end

	def toggle_stage
		@data_version = DataVersion.find(params[:data_version_id])
		@data_version.update("#{params[:stage]}_stage_complete" => !@data_version["#{params[:stage]}_stage_complete"])
		redirect_to carrier_data_version_path(@carrier,  @data_version)
	end

	def processing_pattern
		@data_version = DataVersion.find(params[:data_version_id])
		@data_version.update(:processing_pattern => params[:processing_pattern])
		if @data_version.processing_pattern == "manual"
			redirect_to carrier_data_version_base_rate_tables_path(@carrier,  @data_version, :version_type => @data_version.data_type)
		else
			redirect_to carrier_data_version_path(@carrier,  @data_version)
		end
	end

	def quote_versions_carriers
		@carriers = Carrier.all
	end

	def form_versions_carriers
		@carriers = Carrier.all
	end

	

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def getCurrentStage
		@stages.each do |stage, stage_info|
			if !@data_version["#{stage}_stage_complete"]
				return stage_info
			end
		end
		@data_version.update(:processing_pattern => "finished")
		return ["Finished!", "Congratulations! It looks like you have finished each step in the wizard. Let's navigate back."]
	end
end
