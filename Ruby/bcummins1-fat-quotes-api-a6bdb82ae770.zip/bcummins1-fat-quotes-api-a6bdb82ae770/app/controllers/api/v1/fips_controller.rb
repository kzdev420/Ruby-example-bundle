module Api
	module V1
		class FipsController < ApplicationController
			skip_before_action :verify_authenticity_token, :only => [:create, :export, :show, :test, :index, :destroy, :saveQuestion, :download]
			before_action :authenticate_api_client, :only => [:create, :index, :show, :update, :saveQuestion, :download]

			def create
				body = JSON.parse(request.body.read)
				@form = Form.find(params[:form_id])
    		@fip = Fip.create(:form_id => params[:form_id], :name => body["name"], :user_id => @user.id, :form_structure => @form.get_form_structure)
    		render :json => @fip
			end

			def index
    		@fips = Fip.where(:user_id => @user.id, :form_id => params[:form_id])
    		render :json => @fips, :only => [:name, :id, :form_id] , :root => false
			end

			def show
				@fip = Fip.find(params[:id])
				if @fip.user_id == @user.id
					render :json => @fip
				else
					render status: 401, json: {
				    message: "Unauthorized to view this form."
				  }.to_json
				end
			end

			def saveQuestion
				body = JSON.parse(request.body.read)
				@fip = Fip.find(params[:fip_id])
				structure = JSON.parse(@fip.form_structure)
				structure["sections"].each_with_index  do |section, s_index|
					section["questions"].each_with_index do |question, q_index|
						if question["question_id"] == body["question_id"]
							question["answer"] = body["value"]
						end
					end
				end

				if @fip.update(:form_structure => structure.to_json)
					render :json => @fip, :root => false
				else
					render status: 401, json: {
				    message: "Unauthorized to view this form."
				  }.to_json
				end
			end

			def download
				@fip = Fip.find(params[:fip_id])
				form_structure = JSON.parse(@fip.form_structure)
				filling_hash = {}
  			sections = form_structure["sections"]
  			sections.each do |section|
  				section["questions"].each do |question|
  					q = Question.find(question["question_id"])
  					fillable_field = FillableField.find(q.fillable_id)
  					if fillable_field
  						filling_hash[fillable_field.name] = question["answer"]
  					end
  				end
  			end
  			pdftk = PdfForms.new('/usr/local/bin/pdftk')
  			@form = Form.find(params[:form_id])
  			image = MiniMagick::Image::open(@form.file.to_s)
  			t = SecureRandom.uuid + ".pdf"
		    pdftk.fill_form image.tempfile, t, filling_hash
		    @fip.file = Rails.root.join(t).open
				@fip.save!
				render status: 200, json: {
				    message: "Successfully downloaded",
				    url: @fip.file.url
				  }.to_json


				
			end

			def destroy
    		@fip = Fip.find(params[:id])
    		if @fip.destroy
    			render status: 200, json: {
				    message: "Successfully deleted the form in progress."
				  }.to_json
    		else
    			render 499
    		end
			end
	  		
			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
				@user = @api_client.user
			end

		end
	end
end
