module Api
	module V1
		module Approvals
			class ProductGroupsController < ApplicationController
				
				def index
					@carriers = Carrier.all
					render json: @carriers
				end

			end
		end
	end
end