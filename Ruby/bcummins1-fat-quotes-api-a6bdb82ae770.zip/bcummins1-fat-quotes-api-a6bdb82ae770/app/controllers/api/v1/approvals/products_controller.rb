module Api
	module V1
		module Approvals
			class ProductsController < ApplicationController
				
				def index
					@carriers = Carrier.all
					render json: @carriers
				end

			end
		end
	end
end