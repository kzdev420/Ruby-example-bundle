module Api
	module V1
		module Approvals
			class CarriersController < ApplicationController
				
				def index
					@carriers = Carrier.all
					render json: @carriers
				end

			end
		end
	end
end