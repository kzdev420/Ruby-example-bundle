module Api
	module V1
		class CarriersController < ApplicationController
			skip_before_action :verify_authenticity_token, :only => [:index, :options, :test]
			before_action :authenticate_api_client, :only => [:index, :show, :create]
			before_action :set_headers

			def set_headers
			    headers['Access-Control-Allow-Origin'] = 'http://localhost:3001'
			    headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
			    headers['Access-Control-Request-Method'] = '*'
			    headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Max-Age' 
			  end
			
			def index
				@carriers = Carrier.where(:id => Form.all.pluck(:carrier_id).uniq).order('name ASC')
				render json: @carriers, :include => 
	  										[:product_groups => {:only => [:id,:group_name] }]
			end

			def show
				@carrier = Carrier.find_by_id(params[:id])
				if @carrier
					render json: @carrier, :root => false
				else
					render :json => {"error" => "No carrier with that ID exists"}, :status => 499
				end
				
			end

			def product_types
				@carrier = Carrier.find_by_id(params[:carrier_id])
				if @carrier
					@product_types = ProductGroup.where(:carrier_id => @carrier.id)
					render json: {"product_types" => @product_types }
				else
					render :json => {"error" => "No carrier with that ID exists"}, :status => 499
				end
				
			end

			def products
				@carrier = Carrier.find_by_id(params[:carrier_id])
				if @carrier
					@products = Product.where(:carrier_id => @carrier.id).all
					render json: @products
				else
					render :json => {"error" => "No carrier with that ID exists"}, :status => 499
				end
				
			end

			def test
				head :ok
			end


			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
			end

		end
	end
end