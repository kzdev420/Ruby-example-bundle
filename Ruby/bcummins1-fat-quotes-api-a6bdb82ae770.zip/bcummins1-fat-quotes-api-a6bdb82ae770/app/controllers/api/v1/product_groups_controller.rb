module Api
	module V1
		class ProductGroupsController < ApplicationController
			# before_action :authenticate_api_client, :only => [:index, :show, :create]
			
			def show
				@product_group = ProductGroup.find_by_id(params[:id])
				if @product_group
					render json: @product_group
				else
					render :json => {"error" => "No carrier with that ID exists"}, :status => 499
				end
				
			end

			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
			end

		end
	end
end