module Api
	module V1
		class HealthCategoriesController < ApplicationController
			skip_before_action :verify_authenticity_token, :only => [:create]
			before_action :authenticate_api_client, :only => [:index, :show, :create]

			swagger_controller :health_categories, 'Health Categories'


      		swagger_api :show do
      			summary "Get Health Category Information"
		    	notes "Gets the health category information for this record including the table rate and build chart."
      			param :path, :id, :integer, :required, 'Health Category Id'
				param :query, :api_client_id, :string, :required, '16 digit UUID client specific id.', :defaultValue => "fc6cd7a4-2da9-418d-8740-86eff873b242"
				param :query, :api_token, :string, :required, '16 digit UUID client specific token generated when api client is created.', :defaultValue => "d394acb7-a1dd-4282-a81e-ab4c3768ddd8"
				param :query, :api_profile_id, :string, :required, '16 digit UUID profile specific to tie together API clients from similar organizations', :defaultValue => "6683d9f4-7fc1-4b35-9bba-8738a75c46df"
				response :success
		    	response :unprocessable_entity
			end

			def show
				@health_category = HealthCategory.find(params[:id])
				@build_chart = BuildChart.find(@health_category.build_chart_id) if !@health_category.build_chart_id.nil?
				@table_rate = TableRate.find(@health_category.table_rate_id) if !@health_category.table_rate_id.nil?
				render :json => @health_category, :status => 200
			end

			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
			end

		end
	end
end