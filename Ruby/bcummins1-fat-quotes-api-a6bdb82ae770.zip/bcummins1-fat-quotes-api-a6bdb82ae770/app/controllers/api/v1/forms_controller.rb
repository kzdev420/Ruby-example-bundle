module Api
	module V1
		class FormsController < ApplicationController
			skip_before_action :verify_authenticity_token, :only => [:create, :export, :show, :test]
			before_action :authenticate_api_client, :only => [:create, :show]
			before_action :set_headers

			def set_headers
			    headers['Access-Control-Allow-Origin'] = 'http://localhost:3001'
			    headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
			    headers['Access-Control-Request-Method'] = '*'
			    headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization' 
			  end

			def index
				@new_business_forms = Form.where(:id => FormMapping.where(:product_group_id => params[:product_group], "state_#{params[:state]}" => true, :new_business => true).pluck(:form_id))
				@policyholder_service_forms = Form.where(:id => FormMapping.where(:product_group_id => params[:product_group], "state_#{params[:state]}" => true, :policyholder_service => true).pluck(:form_id))
				@marketing_forms = Form.where(:id => FormMapping.where(:product_group_id => params[:product_group], "state_#{params[:state]}" => true, :marketing => true).pluck(:form_id))
				@contracting_forms = Form.where(:id => FormMapping.where(:product_group_id => params[:product_group], "state_#{params[:state]}" => true, :contracting => true).pluck(:form_id))
				@packet_forms = FormPacket.where(:product_group_id => params[:product_group].to_i, :state => params[:state])

				if params[:fatQuoteTest]
					@carrier = Carrier.find(params[:carrier])
					@product_group = ProductGroup.find(params[:product_group])
					@product_groups = @carrier.product_groups
					@state = params[:state]
					return
				else
					render :json => {:new_business => @new_business_forms, :policyholder_service => @policyholder_service_forms,
									 :marketing => @marketing_forms, :contracting_forms => @contracting_forms, :packet_forms => @packet_forms
									}, :status => 200
				end
			end

			def show
				@form = Form.find(params[:id])
				if @form
					render :json => @form, :root => false
				end
			end

			def test
				head :ok
			end

			def forms_engine
	    		@carriers = Carrier.where(:id => Form.all.pluck(:carrier_id).uniq).order('name ASC')
	    		@product_groups = ProductGroup.all
	  		end

	  		

	  		def template
	  			qs = {"sections" => []}
	  			@form = Form.find(params[:form_id])
	  			@form.sections.each_with_index do |section, sectionIndex|
	  				qs["sections"].push({:name => "section-#{section.id}", :questions => []})
	  				section.ordered_questions.each do |question|
	  					qs["sections"][sectionIndex][:questions].push({:question_id => question.id, :answer => ""})
	  				end
	  			end
	  			render :json => qs
	  		end

	  		def export
	  			filling_hash = {}
	  			sections = params[:sections]
	  			sections.each do |section|
	  				section[:questions].each do |question|
	  					q = Question.find(question[:question_id])
	  					fillable_field = FillableField.find(q.fillable_id)
	  					if fillable_field
	  						filling_hash[fillable_field.name] = question[:answer]
	  					end
	  				end
	  			end
	  			pdftk = PdfForms.new('/usr/local/bin/pdftk')
	  			@form = Form.find(params[:form_id])
	  			image = MiniMagick::Image::open(@form.file.to_s)
			    pdftk.fill_form image.tempfile, 'myform.pdf', filling_hash
	  		end

			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
				@user = @api_client.user
			end
		end
	end
end
