module Api
	module V1
		class QuotesController < ApplicationController
			skip_before_action :verify_authenticity_token, :only => [:create]
			before_action :authenticate_api_client, :only => [:index, :show, :create]

			respond_to :json

			swagger_controller :quotes, 'Quotes'


      		

			def index
				@quote = Quote.find(params[:quote_id])
				@quote_results = JSON.parse(@quote.quote_results_data)
				render :json => @quote_results.to_json, :status => 200
			end

			def new
				
			end

			def show
				@quote_result = Quote.find(params[:id]) rescue nil
				if @quote_result.nil?
					render :json => {"error" => "There is no quote result with that given id"}, :status => 404
					return
				end
				render :json => JSON.parse(@quote_result.quote_results_data), :status => 200
			end
			
			def create
				quoting_params = {
													:api_client_id => params[:api_client_id] ,
													:api_token => params[:api_token] ,
													:api_profile_id => params[:api_profile_id] ,
													:dob => params[:dob] , 
													:state => params[:state_abbr] , 
													:tobacco => params[:tobacco] ,
													:health_category => params[:health_category],
													:product_type_detail => params[:product_type].split(",") , 
													:payment_mode => params[:payment_mode] , 
													:face_amount => params[:coverage_amount].split(",").map{|x| x.to_i},
													:gender => params[:gender].capitalize ,
													:child_rider => params[:child_rider],
													:child_rider_units => params[:child_rider_units].to_i, 
													:wop_rider => params[:wop_rider],
													:adb_rider => params[:adb_rider],
													:table_rating => params[:table_rating],
													:flat_extra => params[:flat_extra]
												 }

				errors = validate_quoting_params(quoting_params)
				if errors.keys.size > 0
					render :json => {"errors" => errors}, :status => 499
					return
				end

				years_between_bday_and_current_year = Date.today.year - Date.parse(quoting_params[:dob]).year  
	    		quoting_params[:age] = Date.today > Date.parse(quoting_params[:dob]) + years_between_bday_and_current_year.years ? years_between_bday_and_current_year.years : years_between_bday_and_current_year.years - 1.years
	    		quoting_params[:age] = quoting_params[:age] / 1.years
	    		next_bday = Date.today > Date.parse(quoting_params[:dob]) + years_between_bday_and_current_year.years ? Date.parse(quoting_params[:dob]) + (years_between_bday_and_current_year.years + 1.years) : Date.parse(quoting_params[:dob]) + (years_between_bday_and_current_year.years)
	    		past_bday = Date.today > Date.parse(quoting_params[:dob]) + years_between_bday_and_current_year.years ? Date.parse(quoting_params[:dob]) + (years_between_bday_and_current_year.years) : Date.parse(quoting_params[:dob]) + (years_between_bday_and_current_year.years - 1.years)
	    		quoting_params[:age_nearest] = DateTime.now + 182.days >  next_bday ?  next_bday.year - Date.parse(quoting_params[:dob]).year : past_bday.year - Date.parse(quoting_params[:dob]).year
				@quote = Quote.create(:api_client_id => @api_client.id, :quote_parameters => quoting_params.to_json)
				quoting_params[:quote_id] = @quote.id;

				quote_results = {}
				quoting_params[:face_amount].each do |amount|
					quoting_params[:amount] = amount
					quote_results[amount] = {}
					quoting_params[:product_type_detail].each do |ptd|
						quoting_params[:ptd] = ptd
						@base_rate_columns = @quote.get_base_rate_columns(@api_client, quoting_params)
						quote_results[amount][ptd] = {}
						quote_results[amount][ptd]["quote_list_id"] = SecureRandom.hex(6)
						quote_results[amount][ptd]["quote_parameters"] = quoting_params
						quote_results[amount][ptd]["results"] = []

						@base_rate_columns.each do |base_rate_column|
							new_quote = base_rate_column.run_quote(quoting_params)
							if new_quote.present?
								@new_quote = QuoteResult.create(new_quote.merge(:quote_id => @quote.id))
								new_quote["quote_id"] = @new_quote.id
								quote_results[amount][ptd]["results"] << new_quote
							end
						end
					end
				end
				
				

				@quote.update(:quote_results_data => quote_results.to_json)
				render :json => quote_results.to_json, :status => 200
				
			end

			def product_types
				render :json => PRODUCT_TYPES.to_json, :status => 200
			end

			def authenticate
				if authenticate_api_client
					render :json => {"success" => "User is successfully authenticated"}, :status => 200
				end
				
			end

			private

			def authenticate_api_client
				@api_client = ApiClient.where(:api_token => params[:api_token], :api_client_id => params[:api_client_id], :api_profile_id => params[:api_profile_id]).first
				if @api_client.nil?
					render :json => {"error" => "No user found with those credentials exists"}, :status => 499
					return
				end
			end

			def validate_quoting_params(quoting_params)
				errors = {}
				if !quoting_params[:dob].match(/\d{4}-\d{2}-\d{2}/) && !quoting_params[:dob].match(/\d{2}/)
					errors["Date of Birth"] = "Date of birth should be in the following format: YYYY-MM-DD. Otherwise, put in an age."
				end
				if !STATE_TO_ABBR_ARRAY.map { |x| x[0]}.include?(params[:state_abbr]) && !STATE_TO_ABBR_ARRAY.map { |x| x[1]}.include?(params[:state_abbr])
					errors["State"] = "No matching state or province"
				end
				if !["Yes", "No"].include?(quoting_params[:tobacco])
					error["Tobacco Status"] = "Please put Yes or No for the tobacco status field."
				end
				if !FAT_QUOTE_HEALTH_CATEGORIES.include?(quoting_params[:health_category])
					errors["Health Category"] = "The following are accepted options for health category: Preferred Plus, Preferred, Standard Plus, Standard"
				end
				if !["male", "female"].include?(quoting_params[:gender].downcase)
					errors["Gender"] = "The following are accepted options for gender: Male, Female."
				end
				if quoting_params[:flat_extra].present? && !(quoting_params[:flat_extra] =~ /\A\d+\z/)
					errors["Flat Extra"] = "Flat Extra Must Be a Number"
				end
				return errors
			end

		end
	end
end