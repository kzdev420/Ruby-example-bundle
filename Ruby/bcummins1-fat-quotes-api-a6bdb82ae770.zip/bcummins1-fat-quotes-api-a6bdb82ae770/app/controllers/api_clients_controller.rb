class ApiClientsController < ApplicationController

	def index
		@api_clients = ApiClient.all
	end

	def new
		@api_client = ApiClient.new
	end

	def create
		@api_client = ApiClient.create(api_client_params)
		@api_client.approval_record = ApprovalRecord.create(:api_client_id => @api_client.id)
		if @api_client.update(:api_token => SecureRandom.uuid, :api_client_id => SecureRandom.uuid, :api_profile_id => SecureRandom.uuid)
			flash[:notice] = "API Client Created"
    		redirect_to api_clients_path
		end
	end

	def show
		@api_client = ApiClient.find(params[:id])

		@carrier_approvals = []
		unless @api_client.approval_record.carrier_approval_record.nil?
			@carrier_approvals = JSON.parse(@api_client.approval_record.carrier_approval_record).map {|c_id| c_id.to_i}
		end
		@carriers = Carrier.all
	end

	def update
		@api_client = ApiClient.find(params[:id])
		@api_client.update(:name => params[:name])
		if @api_client.approval_record.nil?
			@api_client.approval_record = ApprovalRecord.create(:carrier_approval_record => params[:carrier_approvals])
		else
		if @api_client.approval_record.update(:carrier_approval_record => params[:carrier_approvals])
    		flash[:notice] = "Approval Record Successfully Updatedd"
    		redirect_to api_client_path(@api_client)
			end
		end

	end

	def destroy
    @client = ApiClient.find(params[:id])
    @client.destroy
    flash[:notice] = "API Client deleted"
    redirect_to :back
  end

	private


	def api_client_params
    params.require(:api_client).permit(:name)
  end

end
