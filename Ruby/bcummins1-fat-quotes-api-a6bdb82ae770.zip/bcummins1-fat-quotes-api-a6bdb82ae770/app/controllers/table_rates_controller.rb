class TableRatesController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version

	def index
		@table_rates = TableRate.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id).all
    @table_rates2 = TableRate.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id).all
    @table_rate = TableRate.new
	end

	def new
	end

	def create
    @table_rate = TableRate.new(table_rate_params.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id))  

    if @table_rate.save
      flash[:notice] = "Table Rate created!"
      redirect_to carrier_data_version_table_rates_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error creating the table rate"
      redirect_to :back
    end
  end

  def update
    @table_rate = TableRate.find(params[:id])
    if @table_rate.update(table_rate_params)
      flash[:notice] = "Table Rate updated!"
      redirect_to carrier_data_version_table_rates_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error updating the table rate"
      redirect_to :back
    end
  end

	def destroy
		@table_rate = TableRate.find(params[:id])
		if @table_rate.destroy
      flash[:notice] = "Table Rate obliterated!"
      redirect_to carrier_data_version_table_rates_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error deleting the table rate"
      redirect_to :back
    end
	end

	def show
		@table_rate = TableRate.find(params[:id])
	end

	private

		def table_rate_params
	    params.require(:table_rate).permit(:name, :calc_type, :round_rate, :min_face_amount, :max_face_amount, :rate_per_table, :table_A, :table_A_percent, :table_B, 
	                                       :table_B_percent, :table_C, :table_C_percent, :table_D, :table_D_percent, :table_E, :table_E_percent, :table_F, :table_F_percent, 
	                                       :table_G, :table_G_percent, :table_H, :table_H_percent, :wop_applied, :adb_applied, :cir_applied)
	  end

		def set_carrier
			@carrier = Carrier.find(params[:carrier_id]) rescue nil
			if !@carrier
				@errors[:id] = "You are missing the carrier record number"
			end
		end

		def set_data_version
			@data_version = DataVersion.find(params[:data_version_id]) rescue nil
			if !@carrier
				@errors[:id] = "You are missing the carrier record number"
			end
		end
end
