class SectionsController < ApplicationController
  before_action :set_carrier
  before_action :set_data_version
  before_action :set_form

  
  def index
  end

  def new
    @section = Section.new
    @form = Form.find(params[:form_id])
  end

  def update
    @section = Section.find(params[:id])
    @form = @section.form
    if @section.update(section_create_params)
      flash[:notice] = "Section updated!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form"
      redirect_to :back
    end
  end

  def create
    @form = Form.find(params[:form_id])
    @section = Section.new(section_create_params.merge(:form_id => params[:form_id]))
    if @section.save
      flash[:notice] = "Section created!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form"
      redirect_to :back
    end
  end

  def edit
    @section = Section.find(params[:id])
    @form = @section.form
    @questions = @section.questions
  end

  def destroy
    @section = Section.find(params[:id])
    if @section.destroy
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    end
  end

  

  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_form
    @form = Form.find(params[:form_id]) rescue nil
    if !@form
      @errors[:id] = "You are missing the form record number"
    end
  end

  def section_create_params
    params.require(:section).permit(:title, :subtitle, :order)
  end

end