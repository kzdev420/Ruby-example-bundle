class ModalFactorsController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version
	
	def index
		@modal_factors = ModalFactor.where(:data_version_id => @data_version.id)
		@modal_factor = ModalFactor.new
		@base_url = "/carriers/#{@carrier.id}/data_versions/#{@data_version.id}/modal_factors"
	end

	def new
		@modal_factor = ModalFactor.new
	end

	def create
		@modal_factor = ModalFactor.new(modal_factor_params.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id))
    if @modal_factor.save
      flash[:notice] = "modal_factor successfully saved!"
      redirect_to carrier_data_version_modal_factors_path(@carrier, @data_version)
    else
      render :action => "new"
    end
	end

	def show
		@modal_factor = ModalFactor.find(params[:id])
	end

  def edit
    @modal_factor = ModalFactor.find(params[:id])
  end

	def update
		@modal_factor = ModalFactor.find(params[:id])

    if @modal_factor.update(modal_factor_params)
      flash[:notice] = "modal_factor successfully saved!"
      redirect_to carrier_data_version_modal_factors_path(@carrier, @data_version)
    else
      render :action => "edit"
    end
	end

	def destroy
    @modal_factor = ModalFactor.find(params[:id])
    @modal_factor.destroy
    flash[:notice] = "modal_factor deleted"
    redirect_to :back
  end

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def modal_factor_params
    params.require(:modal_factor).permit(:name, :annual_factor, :semi_annual_factor, :quarterly_factor, :monthly_factor, :annual_factor_fee, 
                                         :semi_annual_factor_fee, :quarterly_factor_fee, :monthly_factor_fee)
  end

end
