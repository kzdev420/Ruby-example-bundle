class FormsController < ApplicationController
  before_action :set_carrier, :except => [:forms_engine]
  before_action :set_data_version, :except => [:forms_engine]
  
  def index
    @forms = Form.where(:data_version_id => @data_version.id)
    @base_url = "/carriers/#{@carrier.id}/data_versions/#{@data_version.id}/forms"
  end

  def new
    @form = Form.new
    @product_groups = ProductGroup.where(:carrier_id => @carrier.id)
  end

  def create
    @form = Form.new(form_create_params.merge(:carrier_id => params[:carrier_id], :data_version_id => params[:data_version_id]))
    pgs = params[:product_groups]
    if @form.save
      pgs.each do |pg|
        @form.form_mappings.create(form_type_params.merge(state_params).merge(:product_group_id => pg, :carrier_id => params[:carrier_id], :data_version_id => params[:data_version_id]))
      end
      flash[:notice] = "New form created!"
      redirect_to carrier_data_version_forms_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error creating the form"
      redirect_to :back
    end
  end

  def show
    @form = Form.find(params[:id])
    @form_mappings = @form.form_mappings
    @sections = @form.sections
    @questions = Question.where(:section_id => @sections.ids)
    @fillable_fields = FillableField.where(:form_id => @form.id).order(:created_at)
  end

  def batch_form_upload
    xlsx = Roo::Spreadsheet.open(params[:data_version]["rate_file"].tempfile)
    xlsx.each_with_pagename do |sheet_name, sheet|
      sheet.first_row.upto(sheet.last_row) do |r_index|
        row = sheet.row(r_index)
        form_name = row[0]
        form_number = row[1]
        form_description = row[2]
        form_type = row[3]
        form_mapping = row[4]
        form_state = row[5]
        form_path = row[6]
        form_product_group_id = row[7]

        @form = Form.where(:form_name => form_name, :form_number => form_number, :data_version_id => @data_version.id).first        
        if @form
          @form_mapping = @form.form_mappings.where(:product_group_id => form_product_group_id).first
          if @form_mapping
            @form_mapping.update("state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true) 
          else
            new_form_mapping = FormMapping.create(:form_id => @form.id, :product_group_id => form_product_group_id, :data_version_id => @data_version_id, "state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true)
            
          end
        else
          @form = Form.create(:carrier_id => @carrier.id, :data_version_id => @data_version.id, :form_name => form_name, :form_number => form_number, :description => form_description)
          new_form_mapping = FormMapping.create(:form_id => @form.id, :product_group_id => form_product_group_id, :data_version_id => @data_version_id, "state_#{form_state}" => true, "#{COMPULIFE_FORM_TYPES[form_type]}" => true)
        end
      end 
    end
  end

  def edit
    @form = Form.find(params[:id])
  end

  def parseFields
    @form = Form.find(params[:form_id])
    @pdftk = PdfForms.new('/usr/local/bin/pdftk')
    image = MiniMagick::Image::open(@form.file.to_s)
    @fields = @pdftk.get_fields image.tempfile
    @fields.each do |field|
      @ff = FillableField.find_or_create_by(:flags => field.flags, :name => field.name, :name_alt => field.name_alt, :options => field.options.to_json, :field_type => field.type, :form_id => @form.id)
    end
    redirect_to :back
  end

  def createQuestions
    @form = Form.find(params[:form_id])
    @fields = FillableField.where(:form_id => @form.id).order(:created_at)
    @order = 0
    @fields.each do |field|
      @question = Question.find_or_create_by(:text => field.name, :help_text => field.name_alt, :question_type => field.field_type, :fillable_id => field.id, :form_id => @form.id, :options => field.options)
      @question.update(:order => @order, :options => field.options)
      @order += 1
    end
    redirect_to :back
  end

  def assignQuestions
    @form = Form.find(params[:form_id])
    @sections = @form.sections
    @questions = Question.where(:section_id => nil, :form_id => @form.id)
  end

  def sectionAssignment
    @section = Section.where(:form_id => params[:form_id], :title => params[:title]).first
    @questions = Question.where(:id => params[:questions])
    @questions.each do |question|
      question.update(:section_id => @section.id)
    end
    redirect_to :back
  end

  def destroy
    @form = Form.find(params[:id])
    if @form.destroy
      flash[:notice] = "Form destroyed!"
      redirect_to carrier_data_version_forms_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error deleting the carrier"
      redirect_to :back
    end
    
  end

  def update
    @form = Form.find(params[:id])

    if @form.update(form_create_params)
      flash[:notice] = "Form updated!"
      redirect_to carrier_data_version_form_path(@carrier, @data_version, @form)
    else
      flash[:notice] = "There was an error saving the carrier"
      redirect_to :back
    end
  end

  private

  def set_carrier
    @carrier = Carrier.find(params[:carrier_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def set_data_version
    @data_version = DataVersion.find(params[:data_version_id]) rescue nil
    if !@carrier
      @errors[:id] = "You are missing the carrier record number"
    end
  end

  def form_create_params
    params.require(:form).permit(:form_name, :form_number, :description, :file, :carrier_id, :data_version_id)
  end

  def state_params
    params.permit(:state_AL,:state_AK,:state_AS,:state_AZ,:state_AR,
                                 :state_CA,:state_CO,:state_CT,:state_DE,:state_DC,:state_FM,:state_FL,:state_GA,:state_GU,:state_HI,:state_ID,:state_IL,
                                 :state_IN,:state_IA,:state_KS,:state_KY,:state_LA,:state_ME,:state_MH,:state_MD,:state_MA,:state_MI,:state_MN,:state_MS,
                                 :state_MO,:state_MT,:state_NE,:state_NV,:state_NH,:state_NJ,:state_NM,:state_NY,:state_NC,:state_ND,:state_MP,:state_OH,
                                 :state_OK,:state_OR,:state_PW,:state_PA,:state_PR,:state_RI,:state_SC,:state_SD,:state_TN,:state_TX,:state_UT,:state_VT,
                                 :state_VI,:state_VA,:state_WA,:state_WV,:state_WI,:state_WY)
    
  end

  def form_type_params
    params.permit(:new_business, :policyholder_service, :marketing, :contracting)
  end

end