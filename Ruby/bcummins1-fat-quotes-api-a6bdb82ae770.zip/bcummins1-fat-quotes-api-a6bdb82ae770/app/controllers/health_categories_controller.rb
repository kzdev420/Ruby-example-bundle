class HealthCategoriesController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version
	
	def index
		@health_categories = HealthCategory.where(:carrier_id => @carrier.id, :data_version_id => @data_version.id)
		@base_url = "/carriers/#{@carrier.id}/data_versions/#{@data_version.id}/health_categories"
		@health_category = HealthCategory.new
		@table_rates = TableRate.where(:data_version_id => @data_version.id)
		@build_charts = BuildChart.where(:carrier_id => @carrier.id)
	end

	def create
		@health_category = HealthCategory.new(health_category_params.merge(:carrier_id => @carrier.id, :data_version_id => @data_version.id))
	    if @health_category.save
	      flash[:notice] = "HealthCategory successfully saved!"
	      redirect_to carrier_data_version_health_categories_path(@carrier, @data_version)
	    else
	      flash[:notice] = "There was an error creating this health_category"
	      redirect_to :back
	    end
	end

	def edit
		@health_category = HealthCategory.find(params[:id])
		@table_rates = TableRate.where(:data_version_id => @data_version.id)
		@build_charts = BuildChart.where(:carrier_id => @carrier.id)
	end

	def new
		@health_category = HealthCategory.new
		@table_rates = TableRate.where(:data_version_id => @data_version.id)
		@build_charts = BuildChart.where(:carrier_id => @carrier.id)
	end

	def destroy
		@health_category = HealthCategory.find(params[:id])
		if @health_category.destroy
			flash[:notice] = "Health Category was successfully destroyed"
			redirect_to carrier_data_version_health_categories_path(@carrier, @data_version)
		end
	end

	def update
		@health_category = HealthCategory.find(params[:id])
		if @health_category.update(health_category_params)
      flash[:notice] = "Health Category updated!"
      redirect_to carrier_data_version_health_categories_path(@carrier, @data_version)
    else
      flash[:notice] = "There was an error updating the health category"
      redirect_to :back
    end
	end

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def health_category_params
    	params.require(:health_category).permit(:carrier_health_category, :fat_quote_health_category, :tobacco_category_type, :table_rate_id, :build_chart_id)
  	end

end
