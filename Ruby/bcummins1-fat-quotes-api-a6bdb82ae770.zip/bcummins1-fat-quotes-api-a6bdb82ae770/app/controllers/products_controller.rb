class ProductsController < ApplicationController
	before_action :set_carrier

	def index
		@products = Product.where(:carrier_id => @carrier.id).all
	end

	def new
		@product = Product.new
		@product_groups = ProductGroup.where(:carrier_id => @carrier.id).all
	end

  def edit
    @product = Product.find(params[:id])
  end

	def create
    @product = Product.new(product_params.merge({:carrier_id => @carrier.id, :product_group_id => product_params[:product_group_id]}))
    if @product.save
      @product.update(:state_approval => StateApproval.new(:product_id => @product.id, :use_parent_state_approvals => product_params[:use_product_group_states], :parent_state_approval_id => @product.product_group_id))
      @product.state_approval.reset_state_approval(params[:state_approval])
      flash[:notice] = "Product created!"
      redirect_to carrier_path(@carrier)
    else
      render :action => "new"
    end
  end

  def destroy
    @product = Product.find(params[:id])
    if @product.destroy
      flash[:notice] = "Product destroyed!"
      redirect_to carrier_products_path(@carrier)
    end
  end

  def update
    @product = ::Product.find(params[:id])
    @state_approval = @product.state_approval
    @states_approved = params[:state_approval] || []
    if @product.update(product_params)
      @state_approval.reset_state_approval(@states_approved)
      flash[:notice] = "Successfully updated"
      redirect_to carrier_path(@carrier)
    else
      flash[:notice] = "There was an error"
      redirect_to :back
    end
  end

	private

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You must select a carrier."
		end
	end

	def product_params
    params.require(:product).permit(:product_group_id, :product_name, :line_of_coverage, :product_line, :product_line_detail, :agent_message, :consumer_message, 
                                    :carrier_id, :client_brochure_url1, :client_brochure_url2, :client_brochure_url3, :agent_guide_url1, :agent_guide_url2, :agent_guide_url3, 
                                    :product_description, :quote_notice, :quote_note, :use_product_group_states, :state_AL, :state_AK, :state_AS, :state_AZ, :state_AR, 
                                    :state_CA, :state_CO, :state_CT, :state_DE, :state_DC, :state_FM, :state_FL, :state_GA, :state_GU, :state_HI, :state_ID, :state_IL, 
                                    :state_IN, :state_IA, :state_KS, :state_KY, :state_LA, :state_ME, :state_MH, :state_MD, :state_MA, :state_MI, :state_MN, :state_MS, 
                                    :state_MO, :state_MT, :state_NE, :state_NV, :state_NH, :state_NJ, :state_NM, :state_NY, :state_NC, :state_ND, :state_MP, :state_OH, 
                                    :state_OK, :state_OR, :state_PW, :state_PA, :state_PR, :state_RI, :state_SC, :state_SD, :state_TN, :state_TX, :state_UT, :state_VT, 
                                    :state_VI, :state_VA, :state_WA, :state_WV, :state_WI, :state_WY, :active, :archived, :deleted, :approved_deleted, :carrier_name)
  end

  def state_approval_params
    params.require(:state_approval).permit(:state_AL, :state_AK, :state_AS, :state_AZ, :state_AR, :state_CA, :state_CO, :state_CT, 
                                          :state_DE, :state_DC, :state_FM, :state_FL, :state_GA, :state_GU, :state_HI, :state_ID, :state_IL, :state_IN, :state_IA, :state_KS, 
                                          :state_KY, :state_LA, :state_ME, :state_MH, :state_MD, :state_MA, :state_MI, :state_MN, :state_MS, :state_MO, :state_MT, :state_NE, 
                                          :state_NV, :state_NH, :state_NJ, :state_NM, :state_NY, :state_NC, :state_ND, :state_MP, :state_OH, :state_OK, :state_OR, :state_PW, 
                                          :state_PA, :state_PR, :state_RI, :state_SC, :state_SD, :state_TN, :state_TX, :state_UT, :state_VT, :state_VI, :state_VA, :state_WA, 
                                          :state_WV, :state_WI, :state_WY)
  end

end
