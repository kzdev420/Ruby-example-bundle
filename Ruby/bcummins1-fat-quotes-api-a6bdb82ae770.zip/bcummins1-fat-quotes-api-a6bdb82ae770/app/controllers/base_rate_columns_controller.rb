class BaseRateColumnsController < ApplicationController
	before_action :set_carrier
	before_action :set_data_version
	before_action :set_base_rate_table

	def index
		@base_rate_columns = BaseRateColumn.where(:base_rate_table_id => @base_rate_table.id)
	end

	def show
		@base_rate_column = BaseRateColumn.find(params[:id])
    @product = Product.find(@base_rate_column.base_rate_table.product_id)
    @health_categories = HealthCategory.where(:data_version_id => @data_version.id)
    @health_cat_hash = {}
    @health_categories.each do |cat|
      @health_cat_hash[cat.id] = cat
    end
    @table_rates = TableRate.where(:data_version_id => @data_version.id)
    @modal_factors = ModalFactor.where(:data_version_id => @data_version.id)
    @base_rate_table = BaseRateTable.find(params[:base_rate_table_id])

    @band = Band.find(@base_rate_table.band_id)
    @age_start = 0
    @age_end = 100
    @age_range = @age_end - @age_start
    @age_interval = (@age_range/4).floor
	end

	def update
		@base_rate_table = BaseRateTable.find(params[:base_rate_table_id])
    @base_rate_column = BaseRateColumn.find(params[:id])

    @table_rates = TableRate.where(:data_version_id => @data_version.id)
    @modal_factors = ModalFactor.where(:data_version_id => @data_version.id)
    @band = Band.find(@base_rate_table.band_id)

    if params[:quote_rate][:rates]
      for i in 0..100
          @base_rate_column["age_#{i}"] = params[:quote_rate][:rates]["age_#{i}"].to_f
      end
    end
    

    if @base_rate_column.update(base_rate_column_params)
      @base_rate_column.assign_column_riders
      flash[:notice] = "Column updated!"
      redirect_to carrier_data_version_base_rate_table_path(@carrier, @data_version, @base_rate_table)
    else
    	flash[:notice] = "Column not updated!"
    end
	end

	def destroy
		@base_rate_table = BaseRateTable.find(params[:base_rate_table_id])
		@base_rate_column = BaseRateColumn.find(params[:id])
		if @base_rate_column.destroy
			flash[:notice] = "Column Destroyed!"
      redirect_to carrier_data_version_base_rate_table_path(@carrier, @data_version, @base_rate_table)
		else
			flash[:notice] = "Column not updated!"
			redirect_to carrier_data_version_base_rate_table_base_rate_column_path(@carrier, @data_version, @base_rate_table, @base_rate_column)
		end
	end

  def destroy_all
    @base_rate_table = BaseRateTable.find(params[:base_rate_table_id])
    if @base_rate_table.base_rate_columns.destroy_all
      flash[:notice] = "All Columns Deleted!"
      redirect_to carrier_data_version_base_rate_table_path(@carrier, @data_version, @base_rate_table)
    else
      flash[:notice] = "Columns not deleted!"
      redirect_to carrier_data_version_base_rate_table_base_rate_column_path(@carrier, @data_version, @base_rate_table, @base_rate_column)
    end
  end

	def batch_new
		@male_column_data = {"health_category_ids" => params[:male_health_category_ids], "cat_table_rating_ids" => params[:male_cat_table_rating_ids]} if params[:male_health_category_ids].present?
    @female_column_data = {"health_category_ids" => params[:female_health_category_ids], "cat_table_rating_ids" => params[:female_cat_table_rating_ids]} if params[:female_health_category_ids].present?
    @base_rate_table = BaseRateTable.find(params[:base_rate_table_id])
    @band = Band.find(@base_rate_table.band_id)
    @male_categories = @male_column_data["health_category_ids"].map { |id| HealthCategory.find(id) }
    @female_categories = @female_column_data["health_category_ids"].map { |id| HealthCategory.find(id) }
    @male_health_categories = @male_column_data["health_category_ids"]
    @female_health_categories = @female_column_data["health_category_ids"]
	end

	def batch_new_prepare
		@health_categories = HealthCategory.where(:data_version_id => @data_version.id).all
		@band = Band.find(@base_rate_table.band_id)
    @health_category_hash = {}
    @health_categories.each do |cat|
      @health_category_hash[cat.id] = cat
    end
    @table_rates = TableRate.where(:data_version_id => @data_version.id).all
    @table_rate_hash = {}
    @table_rates.each do |rate|
      @table_rate_hash[rate.id] = rate
    end
    @modal_factors = ModalFactor.where(:data_version_id => @data_version.id).all
    @modal_factor_hash = {}
    @modal_factors.each do |modal_factor|
      @modal_factor_hash[modal_factor.id] = modal_factor
    end
	end

	def batch_new_process
		@base_rate_table = BaseRateTable.find(params[:base_rate_table_id])
    band = Band.find(@base_rate_table.band_id)
    # The array of data from the first step comes through as a string, so we have to JSON parse it
    male_column_data = JSON.parse(params[:male_column_data].gsub(/:([a-zA-z]+)/,'"\\1"').gsub('=>', ': ')).symbolize_keys
    female_column_data = JSON.parse(params[:female_column_data].gsub(/:([a-zA-z]+)/,'"\\1"').gsub('=>', ': ')).symbolize_keys

    ## Iterate through each of the male params and create a column from them
    params[:male_health_category_columns].each_with_index do |(category_id, age_array), index|
      # creates a nice array of all the ages and answers:
      # [[18,"1"], [19, "2"], [20, "15"]]
      ages_and_answers = age_array.to_a
      ages_hash = {}
      ages_and_answers.each do |age_answer|
        ages_hash["age_#{age_answer[0]}".to_sym] = age_answer[1]
      end
      base_rate_column = BaseRateColumn.new(
      													 :data_version_id => @data_version.id, 
                                 :carrier_id => @carrier.id, 
                                 :modal_factor_id => @base_rate_table.modal_factor_id,
                                 :base_rate_table_id => @base_rate_table.id, 
                                 :product_id => @base_rate_table.product_id,
                                 :band_id => band.id, 
                                 :health_category_id => category_id, 
                                 :table_rate_id => male_column_data[:cat_table_rating_ids][index], 
                                 :gender => "Male",
                                 :tobacco => health_category_tobacco_category_type(category_id), 
                                 :face_amount_start => band.face_amount_start, 
                                 :face_amount_end => band.face_amount_end, 
                                 )

      ages_hash.each do |parameter, age|
        base_rate_column.send("#{parameter}=", age)
      end
      base_rate_column.save
      base_rate_column.assign_column_riders
    end

    ## Iterate through each of the male params and create a column from them
    params[:female_health_category_columns].each_with_index do |(category_id, age_array), index|
      # creates a nice array of all the ages and answers:
      # [[18,"1"], [19, "2"], [20, "15"]]
      ages_and_answers = age_array.to_a
      ages_hash = {}
      ages_and_answers.each do |age_answer|
        ages_hash["age_#{age_answer[0]}".to_sym] = age_answer[1]
      end

      base_rate_column = BaseRateColumn.new(
      													 :data_version_id => @data_version.id, 
                                 :carrier_id => @carrier.id, 
                                 :base_rate_table_id => @base_rate_table.id, 
                                 :modal_factor_id => @base_rate_table.modal_factor_id,
                                 :product_id => @base_rate_table.product_id,
                                 :band_id => band.id, 
                                 :health_category_id => category_id, 
                                 :table_rate_id => male_column_data[:cat_table_rating_ids][index], 
                                 :gender => "Female",
                                 :tobacco => health_category_tobacco_category_type(category_id), 
                                 :face_amount_start => band.face_amount_start, 
                                 :face_amount_end => band.face_amount_end, 
                                 )

      ages_hash.each do |parameter, age|
        base_rate_column.send("#{parameter}=", age)
      end
      base_rate_column.save
      base_rate_column.assign_column_riders
    end
    redirect_to carrier_data_version_base_rate_table_path(@carrier, @data_version, @base_rate_table)
	end

	private

	def base_rate_column_params
    params.require(:quote_rate).permit(:gender, :health_category_id, :table_rate_id, :col_type, :use_quote_table_modal_factors, :modal_factor_id, 
                                       :face_amount_start, :face_amount_end, :use_quote_table_adb_riders, :use_quote_table_wop_riders, :use_quote_table_child_riders, 
                                       :use_quote_table_states)
	end

	def set_carrier
		@carrier = Carrier.find(params[:carrier_id]) rescue nil
		if !@carrier
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_data_version
		@data_version = DataVersion.find(params[:data_version_id]) rescue nil
		if !@data_version
			@errors[:id] = "You are missing the carrier record number"
		end
	end

	def set_base_rate_table
		@base_rate_table = BaseRateTable.find(params[:base_rate_table_id]) rescue nil
		if !@base_rate_table
			@errors[:id] = "You are missing the base rate table record number"
		end
	end

	def health_category_tobacco_category_type(id)
    HealthCategory.find(id).tobacco_category_type == "Tobacco" ? true : false
  end

end
