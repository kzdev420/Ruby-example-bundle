module ApplicationHelper
	def state_abbr_comma_list(obj)
    list = []
    ::STATE_TO_ABBR_ARRAY.each do |state|
    	if obj.state_approval.use_parent_state_approvals
    		list << state[1] if ProductGroup.find(obj.state_approval.parent_state_approval_id).state_approval["state_#{state[1]}"]
    	else
    		list << state[1] if obj.state_approval["state_#{state[1]}"]
    	end
      
    end
    return list.join(", ")
  end
end
