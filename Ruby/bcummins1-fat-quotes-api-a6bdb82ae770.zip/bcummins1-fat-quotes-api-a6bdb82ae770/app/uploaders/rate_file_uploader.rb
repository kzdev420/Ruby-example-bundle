# encoding: utf-8

class RateFileUploader < CarrierWave::Uploader::Base
  include CarrierWave::RMagick

  # Choose what kind of storage to use for this uploader:
  storage :fog

  # Override the directory where uploaded files will be stored.
  # This is a sensible default for uploaders that are meant to be mounted:
  def store_dir
    "rate_files/#{model.carrier_id}/#{model.id}"
  end

  def cover 
    manipulate! do |frame, index|
      frame if index.zero?
    end
  end  

  def set_content_type(*args)
    self.file.instance_variable_set(:@content_type, "image/png")
  end 

end