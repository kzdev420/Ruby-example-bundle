
Rails.application.routes.draw do
  match '/api/v1/forms', via: [:options], to:  "api/v1/forms#test"
  match '/api/v1/forms/:id', via: [:options], to:  "api/v1/forms#test"

  match '/api/v1/carriers', via: [:options], to:  "api/v1/carriers#test"

  
  root to: 'carriers#index'
  get '/docs' => redirect('/swagger/dist/index.html?url=/apidocs/api-docs.json')
  get '/apiary' => redirect('api/v1/apiary.html')
  get '/api/v1/product_types' => 'api/v1/quotes#product_types'
  get 'api/v1/carriers' => 'api/v1/carriers#index'

  get '/api/v1/authenticate' => 'api/vi/quotes#authenticate'
  get 'quote_versions_carriers' => 'data_versions#quote_versions_carriers'
  get 'form_versions_carriers' => 'data_versions#form_versions_carriers'

  get 'forms_engine' => 'api/v1/forms#forms_engine'
  devise_for :users
  resources :users
  resources :api_clients
  resources :carriers do
    collection do
      get 'test'  
    end
  	resources :product_groups
  	resources :products
    resources :build_charts
  	resources :data_versions do
      collection do 
        post 'form_dump'
      end
      get 'toggle_stage'
      get 'processing_pattern'
      get 'toggle_active_status'
      resources :forms do
        get 'parseFields'
        get 'createQuestions'
        get 'assignQuestions'
        get 'sectionAssignment'
        resources :fips do 
        end
        resources :fillable_fields do 
        end
        resources :sections do 
          resources :questions do 
          end
        end
        collection do
          patch 'batch_form_upload'
        end
        resources :form_mappings do 
        end
        delete "delete_form_file"
      end
  		resources :bands
  		resources :modal_factors
  		resources :health_categories
  		resources :table_rates
  		resources :rider_rates
  		resources :base_rate_tables do
        collection do
          get 'generate_excel'
          patch 'upload_excel'
          get 'download_results'
        end
        resources :base_rate_columns do
          collection do 
            get 'batch_new_prepare'
            post 'batch_new'
            post 'batch_new_process'
            get 'destroy_all'
          end
        end
      end
  	end
  end

  namespace :api do
    namespace :v1 do
      resources :carriers do
        get 'products'
        get 'product_types'
      end
      resources :product_groups
      resources :quotes
      resources :forms do 
        get 'template'
        post 'export'
        resources :fips do 
          post 'saveQuestion'
          post 'download'

          
        end
      end
      resources :health_categories
      namespace :approvals do
        resources :carriers
        resources :product_groups
        resources :products
      end
    end
  end
end
