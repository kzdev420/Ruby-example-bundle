
if Rails.env.production?
  CONFIG_LOCATION = "ENV"
else
  CARRIERWAVE_CONFIG = Rails.application.config_for(:carrierwave)
  CONFIG_LOCATION = "CARRIERWAVE_CONFIG"
  
end

CarrierWave.configure do |config|
    config.fog_credentials = {
      provider:              'AWS', # required
      aws_access_key_id:     'AKIAIHXTHHAVCGHOORWQ',  # required
      aws_secret_access_key: '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',  # required
      region:                'us-west-2',  # optional, defaults to 'us-east-1'
      host:                  's3-us-west-2.amazonaws.com',  # optional, defaults to nil
      endpoint:              'https://s3-us-west-2.amazonaws.com'   # optional, defaults to nil
    }
    config.fog_directory  = 'fat-quotes-sand'  # required
    config.fog_public     = true                                   # optional, defaults to true
    config.fog_attributes = { 'Cache-Control' => "max-age=#{365.day.to_i}" } # optional, defaults to {}
    config.cache_dir = File.join(Rails.root, 'tmp', 'uploads', Rails.env)
end
