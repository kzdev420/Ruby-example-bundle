STATE_TO_ABBR_ARRAY = [["Alabama","AL"],["Alaska","AK"],["Arizona","AZ"],["Arkansas","AR"],
  ["California","CA"],["Colorado","CO"],["Connecticut","CT"],["Delaware","DE"],["District of Columbia","DC"],
  ["Florida","FL"],["Georgia","GA"],["Hawaii","HI"],
  ["Idaho","ID"],["Illinois","IL"],["Indiana","IN"],["Iowa","IA"],["Kansas","KS"],["Kentucky","KY"],
  ["Louisiana","LA"],["Maine","ME"],["Maryland","MD"],["Massachusetts","MA"],
  ["Michigan","MI"],["Minnesota","MN"],["Mississippi","MS"],["Missouri","MO"],["Montana","MT"],["Nebraska","NE"],
  ["Nevada","NV"],["New Hampshire","NH"],["New Jersey","NJ"],["New Mexico","NM"],["New York","NY"],
  ["North Carolina","NC"],["North Dakota","ND"],["Ohio","OH"],["Oklahoma","OK"],
  ["Oregon","OR"],["Pennsylvania","PA"],["Rhode Island","RI"],
  ["South Carolina","SC"],["South Dakota","SD"],["Tennessee","TN"],["Texas","TX"],["Utah","UT"],["Vermont","VT"],
  ["Virginia","VA"],["Washington","WA"],["West Virginia","WV"],["Wisconsin","WI"],
  ["Wyoming","WY"]]

PROVINCES_TO_ABBR_ARRAY = [["American Samoa","AS"], ["Federated States of Micronesia","FM"], ["Guam","GU"],
                           ["Marshal Islands","MH"], ["Northern Mariana Islands","MP"], ["Palau","PW"], 
                           ["Puerto Rico","PR"], ["Virgin Islands","VI"]]

TERM_PLANS = ["1YearTerm","5YearTerm","10YearTerm","12YearTerm","15YearTerm","16YearTerm","17YearTerm","18YearTerm","19YearTerm","20YearTerm","21YearTerm","22YearTerm","23YearTerm","24YearTerm","25YearTerm","26YearTerm","27YearTerm","28YearTerm","29YearTerm","30YearTerm","31YearTerm","32YearTerm","33YearTerm","34YearTerm","35YearTerm","40YearTerm"]
LIFE_PRODUCT_TYPES = ["Term","Term ROP","UL","Whole Life","Simplified Issue Term","Final Expense"]
LINES_OF_COVERAGE = ["Life"]

PRODUCT_TYPES = {
  "Term" => ["1 Year Term","5 Year Term","10 Year Term", "15 Year Term","20 Year Term","25 Year Term",
             "30 Year Term"],
  "UL" => ["To age 65","To age 65 (ROP)","To age 70","To age 70 (ROP)","To age 75","To age 75 (ROP)","To age 80",
    "To age 85","To age 90","To age 95","To age 100","To age 105","To age 110","To age 121 (No Lapse U/L)","To age 121 (Pay to 65)",
    "To age 121 (Pay to 100)","To age 121 (20 Pay)","To age 121 (10 Pay)","To age 121 (Single Pay)"],
  "Whole Life" => ["Guaranteed Issue", "Non-Participating", "Final Expense"],
  "Simplified Issue Term" => ["1 Year Term Simplified Issue","5 Year Term Simplified Issue","10 Year Term Simplified Issue", "15 Year Term Simplified Issue","20 Year Term Simplified Issue","25 Year Term Simplified Issue",
                              "30 Year Term Simplified Issue"],
  "Final Expense" => ["Final Expense"]
}

COMPULIFE_FORM_TYPES = {"R" => "new_business", "L" => "new_business", "P" => "policyholder_service", 
                        "A" => "policyholder_service", "B" => "policyholder_service", "C" => "policyholder_service",
                        "F" => "policyholder_service", "U" => "policyholder_service", "D" => "policyholder_service",
                        "S" => "policyholder_service", "M" => "marketing", "T" => "contracting", "O" => "other", "N" => "other" 
                        }

FAT_QUOTE_HEALTH_CATEGORIES = ["Preferred Plus","Preferred","Standard Plus","Standard"]

if Rails.env =="development"
  FAT_QUOTE_BASE_URL = "http://localhost:5000/"
else
  FAT_QUOTE_BASE_URL = "https://salty-cove-15590.herokuapp.com/"
end

BUILD_CHART_HEIGHT_WEIGHT_MALE = [["male_5_0_min", "male_5_0_max", "5'0"], ["male_5_1_min", "male_5_1_max", "5'1"], ["male_5_2_min", "male_5_2_max", "5'2"], ["male_5_3_min", "male_5_3_max", "5'3"], ["male_5_4_min", "male_5_4_max", "5'4"], 
                                ["male_5_5_min", "male_5_5_max", "5'5"], ["male_5_6_min", "male_5_6_max", "5'6"], ["male_5_7_min", "male_5_7_max", "5'7"], ["male_5_8_min", "male_5_8_max", "5'8"], ["male_5_9_min", "male_5_9_max", "5'9"],
                                ["male_5_10_min", "male_5_10_max", "5'10"], ["male_5_11_min", "male_5_11_max", "5'11"], ["male_6_0_min", "male_6_0_max", "6'0"], ["male_6_1_min", "male_6_1_max", "6'1"], ["male_6_2_min", "male_6_2_max", "6'2"],
                                ["male_6_3_min", "male_6_3_max", "6'3"], ["male_6_4_min", "male_6_4_max", "6'4"], ["male_6_5_min", "male_6_5_max", "6'5"], ["male_6_6_min", "male_6_6_max", "6'6"], ["male_6_7_min", "male_6_7_max", "6'7"],
                                ["male_6_8_min", "male_6_8_max", "6'8"], ["male_6_9_min", "male_6_9_max", "6'9"], ["male_6_10_min", "male_6_10_max", "6'10"], ["male_6_11_min", "male_6_11_max", "6'11"]]
BUILD_CHART_HEIGHT_WEIGHT_FEMALE = [["female_4_5_min", "female_4_5_max", "4'5"], ["female_4_6_min", "female_4_6_max", "4'6"], ["female_4_7_min", "female_4_7_max", "4'7"], ["female_4_8_min", "female_4_8_max", "4'8"], ["female_4_9_min", "female_4_9_max", "4'9"], 
                                ["female_4_10_min", "female_4_10_max", "4'10"], ["female_4_11_min", "female_4_11_max", "4'11"],["female_5_0_min", "female_5_0_max", "5'0"], ["female_5_1_min", "female_5_1_max", "5'1"], ["female_5_2_min", "female_5_2_max", "5'2"],
                                ["female_5_3_min", "female_5_3_max", "5'3"], ["female_5_4_min", "female_5_4_max", "5'4"], 
                                ["female_5_5_min", "female_5_5_max", "5'5"], ["female_5_6_min", "female_5_6_max", "5'6"], ["female_5_7_min", "female_5_7_max", "5'7"], ["female_5_8_min", "female_5_8_max", "5'8"], ["female_5_9_min", "female_5_9_max", "5'9"],
                                ["female_5_10_min", "female_5_10_max", "5'10"], ["female_5_11_min", "female_5_11_max", "5'11"], ["female_6_0_min", "female_6_0_max", "6'0"], ["female_6_1_min", "female_6_1_max", "6'1"], ["female_6_2_min", "female_6_2_max", "6'2"],
                                ["female_6_3_min", "female_6_3_max", "6'3"], ["female_6_4_min", "female_6_4_max", "6'4"]]
