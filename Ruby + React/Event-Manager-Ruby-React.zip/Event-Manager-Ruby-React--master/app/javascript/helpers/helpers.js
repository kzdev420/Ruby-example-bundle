import { error } from './notifications';


export const handleAjaxError = (err) => {
    error('Something went wrong');
    console.warn(err);
}

export const isEmptyObject = obj => Object.keys(obj).length === 0;

const isValidDate = dateObj => !Number.isNaN(Date.parse(dateObj));

export const validateEvent = (event) => {
  const errors = {};

  if (event.event_type === '') {
    errors.event_type = 'You must enter an event Type';
  }

  if (!isValidDate(event.event_date)) {
    errors.event_date = 'You must enter a valid date';
  }

  if (event.title === '') {
    errors.title = 'You must enter a Title';
  }

  if (event.speaker === '') {
    errors.speaker = 'You must enter at least one Speaker';
  }

  if (event.host === '') {
    errors.host = 'You must enter at least one Host';
  }

  return errors;
}

export const formatDate = (d) => {
    const YYYY = d.getFullYear();
    const MM = `0${d.getMonth() + 1}`.slice(-2);
    const DD = `0${d.getDate()}`.slice(-2);
  
    return `${YYYY}-${MM}-${DD}`;
};