FactoryBot.define do
  factory :conversation do
  end
end
