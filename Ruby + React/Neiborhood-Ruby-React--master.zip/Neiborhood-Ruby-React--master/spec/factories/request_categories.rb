FactoryBot.define do
  factory :request_category do
    category { 'One-time task' }
  end
end
