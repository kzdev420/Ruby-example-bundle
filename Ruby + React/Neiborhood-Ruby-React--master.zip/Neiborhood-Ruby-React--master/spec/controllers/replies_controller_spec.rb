require 'rails_helper'

RSpec.describe RepliesController, type: :controller do

end
